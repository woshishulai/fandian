<template>
  <div class="container">
    <!-- 公共头部 -->
    <Header />

    <div class="conts">
      <div class="crumbs">
        <p>您的位置：首页 > 新闻</p>
      </div>
      <div class="news">
        <div class="main">
          <div class="details">
            <div class="newszuo">
              <div class="newszuo_title">
                2022年，世纪金源用奋斗致敬芳华，用大爱谱写责任
              </div>
              <div class="tishi">
                <span class="time">2022.04.20 13:24</span>
                <span class="jian" @click="jian()">A</span>
                <span class="jia" @click="jia()">A</span>
                <div class="weixin">
                  <img src="../../assets/img/newweixin.png" alt="" />
                </div>
              </div>
              <div class="newszuo_text" ref="ziti">
                <p>
                  4月18日，网商银行发布“网商银行Ⅱ类账户相关业务调整及福利金升级公告”。公告称，4月21日起网商银行将逐步暂停支付宝提现。
                </p>
                <img src="../../assets/img/xin.jpg" alt="" />
              </div>
            </div>
            <div class="newsyou">
              <div class="newsyou_list" @click="qiehuan()">
                <span class="newsyou_list_tit">上一篇</span>
                <span class="time">2022.0.10</span>
                <p>荣耀时刻 | 北京华侨大厦睿世酒店喜获甄选期待新开业酒店奖</p>
              </div>
              <div class="newsyou_list" @click="qiehuan()">
                <span class="newsyou_list_tit">下一篇</span>
                <span class="time">2022.0.10</span>
                <p>荣耀时刻 | 北京华侨大厦睿世酒店喜获甄选期待新开业酒店奖</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 公共底部 -->
    <Footer />
  </div>
</template>

<script>
import Header from "../owned/header.vue";
import Footer from "../owned/footer.vue";
export default {
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      sz: 18,
    };
  },
  created() {
    // 储存第几个头部状态
    localStorage.setItem("istrue", 0);
  },
  methods: {
    //字号加大
    jia() {
      this.sz = this.sz + 1;
      this.$refs.ziti.style.fontSize = this.sz + "px";
      // txt.style.fontSize = sz + 'px';
    },
    //字号减小
    jian() {
        this.sz = this.sz - 1;
        this.$refs.ziti.style.fontSize = this.sz + "px";
    },
    // 切换新闻
    qiehuan() {
      this.$router.push("/newsdetail?date" + Date.now());
    },
  },
  mounted() {},
};
</script>
<style scoped>
.meal_top {
  width: 100%;
  height: 350px;
  position: relative;
}

.meal_top img {
  position: absolute;
  width: 1920px;
  height: 350px;
  left: 50%;
  margin-left: -960px;
  top: 0;
}

.news {
  background-color: #efefed;
}
.details {
  display: flex;
  /* padding: 0 13px; */
  background-color: #fff;
  padding-top: 40px;
}
.details .newszuo {
  width: 1090px;
  padding: 0 13px;
  border-right: 1px solid #eaeaea;
  padding-bottom: 45px;
}
.details .newszuo .newszuo_title {
  padding: 40px 43px;
  padding-top: 0;
  font-size: 30px;
  color: #000000;
  text-align: center;
  font-weight: 400;
}
.details .newszuo .tishi {
  width: 100%;
  height: 88px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-top: 1px solid #eaeaea;
  border-bottom: 1px solid #eaeaea;
}
.details .newszuo .tishi .time {
  font-size: 18px;
  color: #000000;
  margin-right: 35px;
  display: block;
}
.details .newszuo .tishi .jian {
  font-size: 18px;
  color: #000000;
  position: relative;
  margin-right: 37px;
  cursor: pointer;
}
.details .newszuo .tishi .jian::after {
  position: absolute;
  content: "-";
  top: -14px;
  right: -11px;
  z-index: 1;
  font-size: 28px;
}
.details .newszuo .tishi .jia {
  font-size: 18px;
  color: #000000;
  position: relative;
  margin-right: 37px;
  cursor: pointer;
}
.details .newszuo .tishi .jia::after {
  position: absolute;
  content: "+";
  top: -2px;
  right: -10px;
  z-index: 1;
  font-size: 16px;
}
.details .newszuo .newszuo_text {
  width: 1000px;
  margin: auto;
  margin-top: 10px;
  font-size: 18px;
  color: #000000;
}
.details .newszuo .newszuo_text p {
  margin-top: 40px;
}
.details .newszuo .newszuo_text img {
  margin-top: 40px;
  max-width: 100%;
}
.newsyou {
}
.newsyou_list {
  width: 222px;
  margin-bottom: 45px;
  padding-left: 32px;
  position: relative;
  cursor: pointer;
}
.newsyou_list::before {
  position: absolute;
  content: "";
  width: 13px;
  height: 17px;
  top: 12px;
  left: 0;
  z-index: 1;
  background-color: #eaeaea;
}
.newsyou_list .newsyou_list_tit {
  display: block;
  font-size: 24px;
  color: #000000;
  font-weight: 400;
}
.newsyou_list .time {
  display: block;
  margin-top: 10px;
  font-size: 16px;
  color: #000000;
}
.newsyou_list p {
  display: block;
  margin-top: 10px;
  font-size: 18px;
  color: #000000;
}

/* <div class="newsyou_list">
                  <span class="newsyou_list">下一篇</span>
                  <span class="time">2022.0.10</span>
                  <p>荣耀时刻 | 北京华侨大厦睿世酒店喜获甄选期待新开业酒店奖</p>
              </div> */
</style>
