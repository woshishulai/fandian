<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />

        <div class="conts">
            <div class="meal_top">
                <img src="../../assets/img/tiyan.jpg" alt="">
            </div>
            <div class="tiyanone">
                <div class="main">
                    <div class="zhoubian">
                        <div class="zhoubian_tit">周边介绍</div>
                        <div class="zhoubian_lunbo">
                            <div class="swiper-container lunzhou">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="list">
                                            <div class="list_nei">
                                                <span>故宫</span>
                                                <p>北京故宫是中国明清两代的皇家宫殿，旧称紫禁城，位于北京中轴线的中心。北京故宫以三大殿为中心，占地面积约72万平方</p>
                                                <div class="tupian">
                                                    <img src="../../assets/img/tiyan1.jpg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>   
                                    <div class="swiper-slide">
                                        <div class="list">
                                            <div class="list_nei">
                                                <span>故宫</span>
                                                <p>北京故宫是中国明清两代的皇家宫殿，旧称紫禁城，位于北京中轴线的中心。北京故宫以三大殿为中心，占地面积约72万平方</p>
                                                <div class="tupian">
                                                    <img src="../../assets/img/tiyan1.jpg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="swiper-slide">
                                        <div class="list">
                                            <div class="list_nei">
                                                <span>故宫</span>
                                                <p>北京故宫是中国明清两代的皇家宫殿，旧称紫禁城，位于北京中轴线的中心。北京故宫以三大殿为中心，占地面积约72万平方</p>
                                                <div class="tupian">
                                                    <img src="../../assets/img/tiyan1.jpg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>   
                                </div>
                                <!-- 如果需要分页器 -->
                                <div class="swiper-pagination fenye"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tiyantwo">
                <div class="main">
                    <div class="fuwu">
                        <div class="fuwuleft">
                            <img src="../../assets/img/tiyan2.jpg" alt="">
                        </div>
                        <div class="fueurigth">
                            <div class="fueurigth_text">
                                <div class="text_wenben">
                                    <span>服务介绍</span>
                                    <p>我们将致力诠释京心侨情，以挚诚如贵的待客之道，成为中华风范卓越服务的京城坐标。为宾客提供低调奢华的品质服务，体验游子归家般的诚</p>
                                </div>
                            </div>
                            <div class="fueurigth_img">
                                <div class="img">
                                    <img src="../../assets/img/tiyan3.jpg" alt="">
                                </div>
                                <div class="img">
                                    <img src="../../assets/img/tiyan3.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tiyanthere">
                <div class="tiyanthere_tit">酒店图片</div>
                <div class="tiyanthere_lunbo">
                    <div class="swiper-container lunthere">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="there_tu">
                                    <img src="../../assets/img/tilun1.jpg" alt="">
                                </div>
                            </div>       
                            <div class="swiper-slide">
                                <div class="there_tu">
                                    <img src="../../assets/img/tilun2.jpg" alt="">
                                </div>
                            </div>  
                            <div class="swiper-slide">
                                <div class="there_tu">
                                    <img src="../../assets/img/tilun3.jpg" alt="">
                                </div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue";
    import Footer from "../owned/footer.vue";
    import Swiper from "swiper";
    export default {
        components: {
            Header,
            Footer
        },
        data() {
            return {

            };
        },
        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 5);
        },
        methods: {

            //去房型详情页
            newsdeatil(){
                this.$router.push('/newsdetail');
            },
        },
        mounted() {
            var lunzhou = new Swiper(".lunzhou", {
                loop: true, // 循环模式选项
                slidesPerView: 3,
                // autoplay:true,
                // centeredSlides: true,//这个是让第一个居中显示的
                spaceBetween: 69,
                // 如果需要分页器
                pagination: {
                    el: ".swiper-pagination",
                },
            });
            var lunthere = new Swiper(".lunthere", {
                loop: true, // 循环模式选项
                autoplay:true,
                centeredSlides: true,
                // slidesPerView: 3,
                slidesPerView: "auto",
                freeMode:true,
                // autoplay:true,
                // centeredSlides: true,//这个是让第一个居中显示的
                spaceBetween: 0,
                // 如果需要分页器
                pagination: {
                    el: ".swiper-pagination",
                },

            });
        },

    };
</script>
<style scoped>
    .meal_top {
        width: 100%;
        height: 48vw;
        position: relative;
    }

    .meal_top img {
        width: 100%;
        height: 100%;
        display: block;
    }


    .tiyanone{
        width: 100%;
        background-color: #efefed;
    }
    .zhoubian_tit{
        font-size: 30px;
        color: #000000;
        font-weight: 400;
    }
    .zhoubian_lunbo{
        padding-bottom: 50px;
        margin-top: 45px;
    }
    .zhoubian_lunbo .swiper-container{
        padding-bottom: 45px;
    }
    .swiper-container-horizontal > .swiper-pagination-bullets{
        bottom: 0;
    }
    /* .swiper-pagination .swiper-pagination-bullet-active{
        background: #d5b08b;
    } */
    
    .zhoubian_lunbo .swiper-container /deep/ .swiper-pagination-bullet{
        width: 15px ;
        height: 15px ;
        background: #dadada;
        opacity: 1;
        margin: 0 12px;
    }
    .zhoubian_lunbo .swiper-container /deep/ .swiper-pagination-bullet-active{
      background-color: #d5b08b;
    }
    /* .swiper-container-horizontal > .swiper-pagination-bullets > .swiper-pagination-bullet{
        width: 15px !important;
        height: 15px !important;
    } 
    .fenye .swiper-pagination-bullet{
        width: 15px;
        height: 15px;
    } */

    .lunzhou{
        width:100%;
        /* background-color: pink; */
    }
    
    .lunzhou .swiper-slide .list{
        width:420px;
        background-color: #fff;

    }
    .lunzhou .swiper-slide .list .list_nei{
        width:360px;
        margin: auto;
        padding-bottom: 1px;
    }
    .lunzhou .swiper-slide .list .list_nei span{
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 30px;
        color: #000000;
        font-weight: 400;
        padding-top: 30px;
    }
    .lunzhou .swiper-slide .list .list_nei p{
        margin-top: 10px;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        font-size: 18px;
        color: #000000;
        height: 82px;
    }
    .lunzhou .swiper-slide .list .list_nei .tupian{
        width: 360px;
        height: 226px;
        overflow: hidden;
        /* margin: 30px 0; */
          margin: 25px 0 30px;
    }
    .lunzhou .swiper-slide .list .list_nei .tupian img{ 
        width: 100%;
        display: block;
    }
    .tiyantwo{
        padding: 75px 0;
    }
     .tiyantwo .fuwu{
        width: 100%;
        height: 592px;
        display: flex;
        justify-content: space-between;
    }
    .fuwuleft{
        width: 700px;
        height: 100%;
        overflow: hidden;
    }
    .fuwuleft img{
        width: 100%;
        display: block;
    }
    .fueurigth{
        width: 670px;
    }
    .fueurigth .fueurigth_text{
        width: 470px;
        margin: auto;
        /* background-color: pink; */
        height: 382px;
        display: flex;
        align-items: center;
    }
    /* .fueurigth .fueurigth_text .text_wenben{
       
    } */
    
    .fueurigth .fueurigth_text .text_wenben span{
        font-size: 30px;
        color: #000000;
        font-weight: 400;
    }
    .fueurigth .fueurigth_text .text_wenben p{
        margin-top: 15px;
        font-size: 18px;
        line-height: 30px;
        color: #000000;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        height: 90px;
    }
    
    .fueurigth .fueurigth_img{
        display: flex;
        justify-content: space-between;
        height: 211px;
    }
    .fueurigth .fueurigth_img .img{
        width: 320px;
        height: 211px;
        overflow: hidden;
    }
    .fueurigth .fueurigth_img .img img{
        width: 100%;
        display: block;
    }
    .tiyanthere{
        width: 100%;
    }
    .tiyanthere_tit{
        width: 1400px;
        margin: auto;
        font-size: 30px;
        color: #000000;
        font-weight: 400;
    }
    .tiyanthere_lunbo{
        margin-top: 70px;
        
    }
    .tiyanthere_lunbo .lunthere{
        width: 100%;
        height: 710px;
        background-color: #000;
        
    }
    .tiyanthere_lunbo .lunthere .swiper-slide{
        width: 620px;
         opacity: 0.7;
    }
    
    /* .tiyanthere_lunbo .lunthere .swiper-slide{
       
    } */
    .tiyanthere_lunbo .lunthere .swiper-slide-active{
        opacity: 1;
    }

/* 320 211 */



/* 620 710 */

/*


*/
   
</style>