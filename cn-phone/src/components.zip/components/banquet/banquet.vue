<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />

        <div class="conts">
            <div class="meal_top">
                <img src="../../assets/img/cande1.jpg" alt="">
            </div>
            <div class="crumbs">
                <p>您的位置：首页 > 宴会</p>
            </div>
            <div class="canyin">
                <div class="main">
                    <div class="yuxiang">
                        <div class="canyinlun">
                            <div class="swiper-container luncanyin">
                                <!-- 如果需要导航按钮 -->
                                <div class="swiper-button-prev prevcan"></div>
                                <div class="swiper-button-next nextcan"></div>

                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="can_list_img">
                                            <img src="../../assets/img/yanhui1.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="can_list_img">
                                            <img src="../../assets/img/yanhui1.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="can_list_img">
                                            <img src="../../assets/img/yanhui1.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="canyin_right">
                            <div class="canyin_right_text clearfix">
                                <span>宴会简介</span>
                                <p>北京华侨大厦睿世酒店的会议及宴会设施将为您带来现代化的便捷并集聚创意，同时提供多种选择，让您的活动呈现别具一格的风格。金源大宴会厅396平米的活动空间与旋转楼梯的完美邂逅，让您的每一场活动拥有非凡仪式感，是您举办高端会议、婚礼、聚会的理想之选。酒店三层另有三间可灵活组合，设施齐全的现代化会议室可满足您全方面的需求。</p>
                                <div class="anniuyu" @click="yuyan()">预定宴会</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="youhui">
                <div class="main">
                    <div class="vips">
                        <div class="vips_list">
                            <div class="youhui_title">服务</div>
                            <div class="vips_list_img">
                                <img src="../../assets/img/can3.jpg" alt="">
                            </div>
                            <div class="vips_list_text clearfix">
                                <p>位于一层大堂的“城市会客厅”，是人际间交往、交流的重要场所，更是与朋友欢聚小憩，体验时尚下午茶的绝佳场所。</p>
                                <div class="detal">查看详细</div>
                            </div>
                        </div>
                        <div class="vips_list">
                             <div class="youhui_title">纪念日</div>
                            <div class="vips_list_img">
                                <img src="../../assets/img/can3.jpg" alt="">
                            </div>
                            <div class="vips_list_text clearfix">
                               <p>为新婚爱侣倾注最体贴入微的服务，为人生中最重要的日子打造独一无二的难忘时刻。我们的专业婚礼咨询顾问将专注为您所需...</p>
                                <div class="detal">查看详细</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="reserve" v-show="yanhui">
                <div class="resfrom">
                    <div class="resfrom_title">
                        预约 <span>(*必填项)</span>
                    </div>
                    <div class="resfrom_inp">
                        <div class="reslist">
                            <span>姓名*：</span>
                            <div class="reslist_you">
                                <input class="fullname" type="text" name="" id="">
                                <select name="" id="" class="sex">
                                    <option value="1">先生</option>
                                    <option value="2">女士</option>
                                </select>
                            </div>
                        </div>
                        <div class="reslist">
                            <span>电话*：</span>
                            <div class="reslist_you">
                                <input class="quhao" type="text"  placeholder="输入区号">
                                <input class="numbers" type="text" placeholder="请输入电话号码">
                            </div>
                        </div>
                        <div class="reslist">
                            <span>宴会日期*：</span>
                            <div class="reslist_you">
                                <input type="date">
                                <!-- <select name="" id="" >
                                    <option selected hidden disabled>yyyy/mm/dd</option>
                                    <option value="1">先生</option>
                                    <option value="2">女士</option>
                                </select> -->
                            </div>
                        </div>
                        <div class="reslist">
                            <span>邮箱*：</span>
                            <div class="reslist_you">
                                <input type="email" placeholder="请输入邮箱">
                            </div>
                        </div>
                         <div class="reslist">
                            <span>宴会人数*：</span>
                            <div class="reslist_you">
                                <input type="text">
                            </div>
                        </div>
                        <div class="reslist">
                            <span>备注：</span>
                            <div class="reslist_you">
                                <input type="text">
                            </div>
                        </div>
                         <div class="reslist">
                            <span></span>
                            <div class="reslist_you">
                                <!-- <input type="text"> -->
                                <div class="butn butn1"  @click="quxiao()">取消</div>
                                <div class="butn butn2"  @click="queding()">取消</div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- bushi       haorenxuan -->

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue"
    import Footer from "../owned/footer.vue"
    import Swiper from "swiper";
    export default {
        components: {
            Header,
            Footer
        },
        data() {
            return {
                yanhui:true,
            };
        },

        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 4);
        },
        methods: {
            yuyan(){
                this.yanhui=true
            },
            quxiao(){
                this.yanhui=false
            }

            // yanhui(){
            //     // this.yanhui=true
            // }
        },
        mounted() {
            var luncanyin = new Swiper(".luncanyin", {
                loop: true, // 循环模式选项
                autoplay:true,
                // slidesPerView: 4,
                // centeredSlides: true,//这个是让第一个居中显示的
                // spaceBetween: 47,
                navigation: {
                    nextEl: ".nextcan",
                    prevEl: ".prevcan",
                },
            });
        },

    };
</script>
<style scoped>
    .meal_top {
        width: 100%;
        height: 350px;
        position: relative;
    }

    .meal_top img {
        position: absolute;
        width: 1920px;
        height: 350px;
        left: 50%;
        margin-left: -960px;
        top: 0;
    }


    /* 酒吧及餐厅 */
    .canyin {
        width: 100%;
        background-color: #efefed;
        padding-bottom: 74px;
    }

    .yuxiang {
        background-color: #fff;
        display: flex;
        height: 520px;
    }


    .canyinlun {
        width: 545px;
        height: 520px;
        position: relative;
    }
    .prevcan,.nextcan{
        color: #fff;
        top: 100%;
        margin-top: -55px;
    }
    .prevcan{
        left: 38px;
    }
    .nextcan{
        right: 38px;
    }
    .prevcan:after,.nextcan:after{
        font-size: 25px;
    }

    .canyinlun .luncanyin {
        width: 100%;
        height: 100%;
    }

    .canyinlun .luncanyin .swiper-slide {
        width: 100%;
        height: 100%;
    }
    .canyin_right{
        display: flex;
        align-items: center;
        justify-content: center;
        width: 855px;
    }
    .canyin_right .canyin_right_text{
        width: 715px;
    }
    .canyin_right .canyin_right_text>span {
        font-size: 30px;
        color: #000000;
    }

    .canyin_right .canyin_right_text>p {
        line-height: 30px;
        margin-top: 25px;
        font-size: 18px;
        color: #000000;
         display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 5;
        /*要显示的行数*/
        -webkit-box-orient: vertical;
    }
    .anniuyu{
        margin-top: 100px;
        width: 185px;
        height: 55px;
        background-color: #d5b08b;
        font-size: 20px;
        color: #fff;
        line-height: 55px;
        text-align: center;
        float: right;
        cursor: pointer;
    }

    .youhui {
        width: 100%;
    }

    .youhui .vips {
        display: flex;
        justify-content: space-between;
        padding-bottom: 50px;
    }

    .youhui .vips .vips_list{
        cursor: pointer;
        width: 670px;
    }
    .youhui .vips .vips_list .youhui_title {
        font-size: 30px;
        color: #000000;
        font-weight: 400;
        padding: 40px 0;
    }

    .youhui .vips .vips_list .vips_list_img {
        width: 670px;
        height: 380px;
        overflow: hidden;
    }

    .youhui .vips .vips_list .vips_list_img img {
        width: 100%;
        display: block;
        transition: all 0.5s;
    }

    .youhui .vips .vips_list:hover .vips_list_img img {
        transform: scale(1.2);
    }

    .youhui .vips .vips_list .vips_list_text {
        background-color: #efefed;
        padding: 45px 50px 60px;
    }

    .youhui .vips .vips_list .vips_list_text p {
        font-size: 18px;
        color: #010101;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 2;
        /*要显示的行数*/
        -webkit-box-orient: vertical;
        line-height: 30px;
        height: 60px;
    }
    .youhui .vips .vips_list .vips_list_text .detal{
        float: right;
        margin-top: 10px;
        font-size: 18px;
        color: #a8916f;
    }
    .reserve{
        background-color: rgba(0, 0, 0, .5);
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9;
        display: flex;
        align-items: center;
    }
    .reserve .resfrom{
        width: 1000px;
        height: 870px;
        background: #fff;
        margin: auto;
    }
    .resfrom_title{
        height: 100px;
        background: #f4f4f4;
        width: 100%;
        font-size: 30px;
        color: #000000;
        line-height: 100px;
        text-align: center;
    }
    .resfrom_title span{
        font-size: 20px;
        color: #000000;
    }
    .resfrom_inp{
        width: 580px;
        margin: auto;
    }
    .reslist{
        margin-top: 39px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .reslist span{
       width: 147px;
       font-size: 20px;
       color: #000000;
    }
    .reslist .reslist_you{
        /* hahahaha */
        width: 433px;
        /* background-color: #f4f4f4; */
        height: 52px;
    }
    .reslist .reslist_you{
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .reslist .reslist_you input{
        outline: none;
        border: none;
        border-radius: 5px;
    }
    .reslist .reslist_you input{
        width: 100%;
        height: 100%;
        background-color: #f4f4f4;
        font-size: 18px;
        color: #575757;
        padding-left: 26px;
        box-sizing: border-box;
    }
    .reslist .reslist_you .fullname{
        width: 243px;
    }
    .reslist .reslist_you .sex{
        width: 170px;
        height: 100%;
        background-color: #f4f4f4;
        outline: none;
        border: none;
        border-radius: 5px;
        padding:0 26px;
        box-sizing: border-box;
    }
    .reslist .reslist_you .quhao{
        width: 170px;
    }
    .reslist .reslist_you .numbers{
        width: 243px;
    }
    .butn{
        width: 190px;
        height: 52px;
        line-height: 52px;
        font-size: 20px;
        color: #fff;
        text-align: center;
        border-radius: 5px;
        cursor: pointer;
    }
    .butn1{
        background-color: #cfcfcf;
    }
    .butn2{
        background-color: #d5b08b;
    }

</style>