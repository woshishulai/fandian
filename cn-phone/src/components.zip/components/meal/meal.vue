<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />
        <div class="conts">
            <div class="meal_top">
                <img src="../../assets/img/hotle1.jpg" alt="">
            </div>
            <div class="canyin">
                <div class="main">
                    <div class="introdu">
                        <span class="introdu_tie">酒吧及餐厅</span>
                        <p>中华传统佳肴与东南亚风味料理的多元风味，以燕京八景为巧思进行现代演绎的典雅环境，令客人在愉悦中唤醒味蕾；创新前卫的美食理念与传</p>
                    </div>
                    <div class="canyinlun">
                        <!-- 如果需要导航按钮 -->
                        <!-- <div class="swiper-button-prev prevcan"></div>
                        <div class="swiper-button-next nextcan"></div> -->
                        <div class="swiper-container luncanyin">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="can_list">
                                        <div class="can_list_img">
                                            <img src="../../assets/img/can2.jpg" alt="">
                                        </div>
                                        <div class="can_list_text">
                                            <p>御香苑1</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="can_list">
                                        <div class="can_list_img">
                                            <img src="../../assets/img/can2.jpg" alt="">
                                        </div>
                                        <div class="can_list_text">
                                            <p>御香苑2</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="can_list">
                                        <div class="can_list_img">
                                            <img src="../../assets/img/can2.jpg" alt="">
                                        </div>
                                        <div class="can_list_text">
                                            <p>御香苑3</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="youhui">
                <div class="main">
                    <div class="youhui_title">专享优惠</div>
                    <div class="vips">
                        <div class="vips_list">
                            <div class="vips_list_img">
                                <img src="../../assets/img/can3.jpg" alt="">
                            </div>
                            <div class="vips_list_text">
                                <span>一期一会|静待花开 温暖相见</span>
                                <p>会员专享折扣</p>
                            </div>
                        </div>
                        <div class="vips_list">
                            <div class="vips_list_img">
                                <img src="../../assets/img/can3.jpg" alt="">
                            </div>
                            <div class="vips_list_text">
                                <span>清明节|万物生长树</span>
                                <p>每月初12号享受活动</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue"
    import Footer from "../owned/footer.vue"
    import Swiper from "swiper";
    export default {
        components: {
            Header,
            Footer
        },
        data() {
            return {

            };
        },

        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 3);
        },
        methods: {


        },
        mounted() {
            var luncanyin = new Swiper(".luncanyin", {
                loop: true, // 循环模式选项
                autoplay:true,
                slidesPerView: 2,
                // centeredSlides: true,//这个是让第一个居中显示的
                spaceBetween: 10,//47
                // navigation: {
                //     nextEl: ".nextcan",
                //     prevEl: ".prevcan",
                // },
            });
        },

    };
</script>
<style scoped>
    .meal_top {
        width: 100%;
        height: 48.000vw;
        position: relative;
    }

    .meal_top img {
        width: 100%;
        height: 100%;
        display: block;
    }

    /* 酒吧及餐厅 */
    .canyin {
        width: 100%;
        background-color: #efefed;
        padding-bottom: 5.333vw;
        padding-top: 4.000vw;
    }

    .canyin .introdu span {
        font-size: 5vw;
        color: #000000;
        font-weight: 400;
    }

    .canyin .introdu p {
        margin-top: 2.667vw;
        font-size: 3.2vw;
        color: #5f5f5f;
        width: 100%;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 3;
        /*要显示的行数*/
        -webkit-box-orient: vertical;
        line-height: 5vw;
        height: 15vw;
        text-align: justify;
    }

    .canyinlun {
        width: 100%;
        padding-top: 5.333vw;
        position: relative;
        /* margin-left: -4.000vw; */
    }

    .canyinlun .luncanyin {
        width: 100%;
        
    }

    /* .prevcan,
    .nextcan {
        width: 44px;
        height: 44px;
        background-repeat: no-repeat;
        background-size: 100%;
        background: url(../../assets/img/canjt.png);
        top: -75px;
    }

    .prevcan {
        left: 1250px;
    }

    .nextcan {
        right: 0;
        transform: rotate(180deg);
    }

    .prevcan::after,
    .nextcan::after {
        display: none;
    } */

    /* .canyinlun .luncanyin .swiper-slide {
        width: 42.667vw !important;
        margin-right: 4.000vw;
    } */

    /* .canyinlun .luncanyin .swiper-slide .can_list {
        cursor: pointer;
    } */

    /* .canyinlun .luncanyin .swiper-slide .can_list:hover .can_list_img img {
        transform: scale(1.2);
    } */
    .can_list{
        width: 42.667vw;
        overflow: hidden;
    }
    .can_list .can_list_img {
        width: 42.667vw;
        height: 40.667vw;
        overflow: hidden;
    }

    .can_list .can_list_img img {
        width: 100%;
        display: block;
        /* transition: all 0.5s; */
    }

    .can_list .can_list_text {
        background-color: #fff;
        height: 12.000vw;
        /* width: 100%; */
        width: 42.667vw;
       
    }

    .can_list .can_list_text p {
        line-height: 12.000vw;
        text-align: center;
        font-size: 3.8vw;
        color: #000000;
    }

    .youhui {
        width: 100%;

    }

    .youhui .youhui_title {
        font-size: 5vw;
        color: #000000;
        font-weight: 400;
        margin-top: 5.333vw;
    }

    .youhui .vips {
       
        /* display: flex; */
        justify-content: space-between;
        padding-bottom: 5.333vw;
    }

    .youhui .vips .vips_list {
        cursor: pointer;
        width: 100%;
        margin-top: 5.333vw;
    }

    .youhui .vips .vips_list .vips_list_img {
        width: 100%;
        /* height: 380px; */
        height: 56.400vw;
        overflow: hidden;
    }

    .youhui .vips .vips_list .vips_list_img img {
        width: 100%;
        display: block;
        /* transition: all 0.5s; */
    }

    /* .youhui .vips .vips_list:hover .vips_list_img img {
        transform: scale(1.2);
    } */

    .youhui .vips .vips_list .vips_list_text {
        margin-top: 4.333vw;
    }

    .youhui .vips .vips_list .vips_list_text span {
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 3.8vw;
        color: #000000;
    }

    .youhui .vips .vips_list .vips_list_text p {
        margin-top: 1.5.000vw;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        display: block;
        font-size: 3.2vw;
        color: #000000;
    }
    

</style>