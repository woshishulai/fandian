<template>
  <div class="container">
    <!-- 公共头部 -->
    <Header />

    <div class="conts">
      <div class="meal_top">
        <img src="../../assets/img/cande1.jpg" alt="" />
        <!-- hotle1 -->
      </div>
      <div class="canyin">
        <div class="main">
          <div class="yuxiang">
            <div class="canyinlun">
              <div class="swiper-container luncanyin">
                <!-- 如果需要导航按钮 -->
                <div class="swiper-button-prev prevcan"></div>
                <div class="swiper-button-next nextcan"></div>
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="can_list_img">
                      <img src="../../assets/img/cande2.jpg" alt="" />
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="can_list_img">
                      <img src="../../assets/img/cande2.jpg" alt="" />
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="can_list_img">
                      <img src="../../assets/img/cande2.jpg" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="canyin_right">
              <div class="canyin_right_text">
                <span>御香苑</span>
                <p>
                  位于酒店二层的御香苑，由岭南画派大师关山月先生亲笔题字，设置大厅及7间包厢，主打官府菜肴，严选时令新鲜食材，传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断传承传统技艺又不断
                </p>
                <div class="cancont">
                  <div class="rig_list">
                    <img src="../../assets/img/icon1.png" alt="" />
                    <div class="rig_listtxt">
                      <span>营业时间</span>
                      <p>午餐: 11:30 - 14:00 , 晚餐: 17:30 - 22:00</p>
                    </div>
                  </div>
                  <div class="rig_list">
                    <img src="../../assets/img/icon2.png" alt="" />
                    <div class="rig_listtxt">
                      <span>电话</span>
                      <p>+86 10 65136666 转 6737</p>
                    </div>
                  </div>
                  <div class="rig_list">
                    <img src="../../assets/img/icon3.png" alt="" />
                    <div class="rig_listtxt">
                      <span>位置</span>
                      <p>酒店二层</p>
                    </div>
                  </div>
                  <div class="rig_list">
                    <img src="../../assets/img/icon4.png" alt="" />
                    <div class="rig_listtxt">
                      <span>菜式</span>
                      <p>官府菜</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="youhui">
        <div class="main">
          <div class="youhui_title">其他餐饮推荐</div>
          <div class="vips">
            <div class="vips_list">
              <div class="vips_list_img">
                <img src="../../assets/img/can3.jpg" alt="" />
              </div>
              <div class="vips_list_text">
                <span>嘉邸</span>
              </div>
            </div>
            <div class="vips_list">
              <div class="vips_list_img">
                <img src="../../assets/img/can3.jpg" alt="" />
              </div>
              <div class="vips_list_text">
                <span
                  >嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸嘉邸</span
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--  -->
    <!-- 公共底部 -->
    <Footer />
  </div>
</template>

<script>
import Header from "../owned/header.vue";
import Footer from "../owned/footer.vue";
import Swiper from "swiper";
export default {
  components: {
    Header,
    Footer,
  },
  data() {
    return {};
  },

  created() {
    // 储存第几个头部状态
    localStorage.setItem("istrue", 3);
  },
  methods: {},
  mounted() {
    var luncanyin = new Swiper(".luncanyin", {
      loop: true, // 循环模式选项
      autoplay: true,
      // slidesPerView: 4,
      // centeredSlides: true,//这个是让第一个居中显示的
      // spaceBetween: 47,
      navigation: {
        nextEl: ".nextcan",
        prevEl: ".prevcan",
      },
    });
  },
};
</script>
<style scoped>
.meal_top {
  width: 100%;
  height: 48vw;
  position: relative;
}

.meal_top img {
  width: 100%;
  height: 100%;
  display: block;
}

/* 酒吧及餐厅 */
.canyin {
  width: 100%;
  background-color: #efefed;
  padding-bottom: 5.2vw;
  padding-top: 5.067vw;
}

.yuxiang {
  background-color: #fff;
  /* display: flex; */
  /* height: 520px; */
}

.canyinlun {
  width: 100%;
  /* height: 520px; */
  height: 85.467vw;
  position: relative;
}
.canyinlun .can_list_img {
  width: 100%;
  height: 100%;
}
.canyinlun .can_list_img img {
  width: 100%;
  height: 100%;
  display: block;
}
.prevcan,
.nextcan {
  color: #fff;
  top: 50%;
  /* margin-top: -55px; */
}
.prevcan {
  left: 3.867vw;
}
.nextcan {
  right: 3.867vw;
}
.prevcan:after,
.nextcan:after {
  font-size: 7vw;
}

.canyinlun .luncanyin {
  width: 100%;
  height: 100%;
}

.canyinlun .luncanyin .swiper-slide {
  width: 100%;
  height: 100%;
}
.canyin_right {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 76.8vw;
  margin: auto;
  margin-top: 6vw;
}
.canyin_right .canyin_right_text {
  /* width: 715px; */
}
.canyin_right .canyin_right_text > span {
  font-size: 5vw;
  color: #000000;
}

.canyin_right .canyin_right_text > p {
  line-height: 5vw;
  margin-top: 3.733vw;
  font-size: 3.6vw;
  color: #000000;
  display: -webkit-box;
  overflow: hidden;
  text-overflow: ellipsis;
  -webkit-line-clamp: 5;
  /*要显示的行数*/
  -webkit-box-orient: vertical;
}
.cancont {
  border-top: 0.133vw solid #efefed;
  margin-top: 4.667vw;
  padding-top: 4.667vw;
}
.rig_list {
  /* margin-top: 36px; */
  display: flex;
  align-items: flex-start;
  margin-bottom: 6.667vw;
}

.rig_list > img {
  width: 3.333vw;
  height: 3.067vw;
  display: block;
  margin-right: 2.667vw;
  margin-top: 1.3vw;
}

.rig_list > .rig_listtxt span {
  font-size: 3.5vw;
  color: #000000;
}

.rig_list > .rig_listtxt p {
  font-size: 3.5vw;
  color: #000000;
}

.youhui {
  width: 100%;
}

.youhui .youhui_title {
  font-size: 5vw;
  color: #000000;
  font-weight: 400;
  margin-top: 5.333vw;
}

.youhui .vips {
  /* display: flex; */
  justify-content: space-between;
  padding-bottom: 5.333vw;
}

.youhui .vips .vips_list {
  cursor: pointer;
  width: 100%;
  margin-top: 5.333vw;
}

.youhui .vips .vips_list .vips_list_img {
  width: 100%;
  /* height: 380px; */
  height: 56.4vw;
  overflow: hidden;
}

.youhui .vips .vips_list .vips_list_img img {
  width: 100%;
  display: block;
  /* transition: all 0.5s; */
}

.youhui .vips .vips_list .vips_list_text {
  margin-top: 4.333vw;
}

.youhui .vips .vips_list .vips_list_text span {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: 4vw;
  color: #000000;
}

/* .youhui .vips .vips_list .vips_list_text p {
  margin-top: 1.5.000vw;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  display: block;
  font-size: 3.2vw;
  color: #000000;
} */

</style>
