<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />

        <div class="conts">
            <div class="meal_top">
                <img src="../../assets/img/shiji.jpg" alt="">
            </div>
            <div class="crumbs">
                <p>您的位置：首页 > 世纪会</p>
            </div>
            <div class="ambitus">
                <div class="main">
                    <div class="assoc">
                        <div class="shiji">
                            <div class="shiji_logo"><img src="../../assets/img/shijilogo.png" alt=""></div>
                            <p class="jiaru">加入世纪会体验我们为您提供贴心贴意的服务</p>
                        </div>
                        <div class="buttons">
                            <div class="btn" @click="denglv()">登录</div>
                            <div class="btn" @click="zhuce()">注册</div>
                        </div>
                    </div>
                    <div class="huiyuan">
                        <div class="huiyuan_text">
                            <img src="../../assets/img/shiji.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue";
    import Footer from "../owned/footer.vue";
    export default {
        components: {
            Header,
            Footer
        },
        data() {
            return {

            };
        },
        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 6);
        },
        inject:['reload'],
        methods: {
            denglv(){
                localStorage.setItem("loginfou", 1);
                // console.log(localStorage.getItem("loginfou"))
                this.reload();
            },
            zhuce(){
                localStorage.setItem("loginfou", 2);
                this.reload();
            }
        },
        mounted() {
            
        },

    };
</script>
<style scoped>
    .meal_top {
        width: 100%;
        height: 350px;
        position: relative;
    }

    .meal_top img {
        position: absolute;
        width: 1920px;
        height: 350px;
        left: 50%;
        margin-left: -960px;
        top: 0;
    }

    .ambitus{
        width: 100%;
        background-color: #efefed;
    }
    .assoc .shiji {
        width: 100%;
    }

    .assoc .shiji .shiji_logo {
        width: 122px;
        height: 86px;
        margin: auto;
        text-align: center;
    }

    .assoc .shiji .shiji_logo img {
        width: 100%;
        height: 100%;
        display: block;
    }

    .assoc .shiji .jiaru {
        text-align: center;
        margin: auto;
        font-size: 18px;
        color: #5f5f5f;
        margin-top: 30px;
        font-weight: 400;
    }
    .assoc .buttons{
        margin-top: 30px;
        display: flex;
        /* margin: auto; */
        justify-content: center;
    }
    .assoc .buttons .btn{
        width: 185px;
        height: 55px;
        background-color: #d5b08b;
        text-align: center;
        color: #fff;
        line-height: 55px;
        font-size: 20px;
        margin: 0 45px;
        cursor: pointer;
    }
    .huiyuan{
        width: 100%;
        background: #fff;
        padding: 35px 0;
        margin-top: 80px;
    }
    .huiyuan .huiyuan_text{
        width: 1100px;
        margin: auto;
    }
    .huiyuan .huiyuan_text img{
        max-width: 100%;
    }

    
</style>