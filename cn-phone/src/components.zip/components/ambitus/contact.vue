<template>
  <div class="container">
    <!-- 公共头部 -->
    <Header />

    <div class="conts">
      <div class="conts_top">
        <img src="../../assets/img/falv.jpg" alt="" />
        <p>联系我们</p>
      </div>
      <div class="crumbs">
        <p>您的位置：首页 > 联系我们</p>
      </div>
      <div class="ambitus">
        <div class="main">
          <div class="lianxi">
            <div class="lianxileft">
              <div class="jieshao">
                <span>酒店介绍</span>
                <p>
                  北京世纪金源大饭店拥有各类客房553间套。金世纪中餐厅、金源自助餐厅、富士山日本料理餐厅、御景
                  苑大堂酒廊、流香轩茶艺居、一殿酒吧，为宾客品尝饕鸞盛宴提供了奢华舒适的场所。其中-殿酒吧以
                  其独享特供的纯麦芽威士忌而享誉京城。1700平方米无柱式千人宴会厅，可容纳1000人同时就餐。地下
                  不夜城名晶店铺、经典美食、健身、休闲、娱乐，应有尽有、美不暇接。
                </p>
                <div class="list">
                  <span>地址：</span>
                  <p>北京市海淀区板井路69号</p>
                </div>
                <div class="list">
                  <span>邮编：</span>
                  <p>1000097</p>
                </div>
                <div class="list">
                  <span>总机：</span>
                  <p>010-88598888</p>
                </div>
                <div class="list">
                  <span>传真：</span>
                  <p>010-88599999</p>
                </div>
              </div>
              <div class="ditu">
                <!--百度地图容器-->
                <div style="width: 820px; height: 300px; border: #ccc solid 1px" id="dituContent"></div>
              </div>
            </div>
            <div class="lianxiright">
                <div class="lianxi_form">
                    <div class="xinxi">
                        <span>联络我们</span>
                        <p>如果您有任何问题或意见，请通过一下方式与我们联系，我们会尽快回复。</p>
                    </div>
                    <div class="inpform">
                        <div class="inplist">
                            <p>姓名：</p>
                            <div class="inp">
                                <input type="text" v-model="name">
                                <p v-show="nameshow">请填写姓名</p>
                            </div>
                        </div>
                        <div class="inplist">
                            <p>电话：</p>
                            <div class="inp">
                                <input type="text" v-model="phone">
                                <p v-show="phoneshow">请填写电话</p>
                            </div>
                        </div>
                        <div class="inplist">
                            <p>邮箱：</p>
                            <div class="inp">
                                <input type="text" v-model="email">
                                <p v-show="emailshow">请填写电话</p>
                            </div>
                        </div>
                        <div class="inplist clearfix">
                            <p>留言内容：</p>
                            <div class="inptext">
                                <textarea cols="30" rows="10" v-model="wenben" maxlength="200" οnchange="this.value=this.value.substring(0, 200)" οnkeydοwn="this.value=this.value.substring(0, 200)" οnkeyup="this.value=this.value.substring(0, 200)"></textarea>
                                <p v-show="wenbenshow" >请填写电话</p>
                            </div>
                            <div class="shuzi">{{wenben.length}}/200</div>
                        </div>
                        <div class="tijiao" @click="tijiao()">提交</div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 公共底部 -->
    <Footer />
  </div>
</template>

<script>
import Header from "../owned/header.vue";
import Footer from "../owned/footer.vue";
export default {
  components: {
    Header,
    Footer,
  },
  data() {
    return {
        name:'',
        phone:'',
        email:'',
        wenben:'',
        nameshow:false,
        phoneshow:false,
        emailshow:false,
        wenbenshow:false,

    };
  },
  created() {
    // 储存第几个头部状态
    localStorage.setItem("istrue", 0);
  },
  methods: {
    tijiao(){
        console.log(this.name)
        console.log(this.phone)
        console.log(this.email)
        console.log(this.wenben)
        if(this.name==""){
            this.nameshow=true
            setTimeout(() => {
                this.nameshow=false
            }, 3000);
        }
    },
  },
  mounted() {
    //创建和初始化地图函数：
    function initMap(){
        createMap();//创建地图
        setMapEvent();//设置地图事件
        addMapControl();//向地图添加控件
        addMarker();//向地图中添加marker
    }
    
    //创建地图函数：
    function createMap(){
        var map = new BMap.Map("dituContent");//在百度地图容器中创建一个地图
        var point = new BMap.Point(116.286803,39.959512);//定义一个中心点坐标
        map.centerAndZoom(point,17);//设定地图的中心点和坐标并将地图显示在地图容器中
        window.map = map;//将map变量存储在全局
    }
    
    //地图事件设置函数：
    function setMapEvent(){
        map.enableDragging();//启用地图拖拽事件，默认启用(可不写)
        map.enableScrollWheelZoom();//启用地图滚轮放大缩小
        map.enableDoubleClickZoom();//启用鼠标双击放大，默认启用(可不写)
        map.enableKeyboard();//启用键盘上下左右键移动地图
    }
    
    //地图控件添加函数：
    function addMapControl(){
        //向地图中添加缩放控件
	var ctrl_nav = new BMap.NavigationControl({anchor:BMAP_ANCHOR_TOP_LEFT,type:BMAP_NAVIGATION_CONTROL_LARGE});
	map.addControl(ctrl_nav);
        //向地图中添加缩略图控件
	var ctrl_ove = new BMap.OverviewMapControl({anchor:BMAP_ANCHOR_BOTTOM_RIGHT,isOpen:1});
	map.addControl(ctrl_ove);
        //向地图中添加比例尺控件
	var ctrl_sca = new BMap.ScaleControl({anchor:BMAP_ANCHOR_BOTTOM_LEFT});
	map.addControl(ctrl_sca);
    }
    
    //标注点数组
    var markerArr = [{title:"北京世纪金源大饭店",content:"电话：010-88598888",point:"116.286812|39.959567",isOpen:1,icon:{w:21,h:21,l:0,t:0,x:6,lb:5}}
		 ];
    //创建marker
    function addMarker(){
        for(var i=0;i<markerArr.length;i++){
            var json = markerArr[i];
            var p0 = json.point.split("|")[0];
            var p1 = json.point.split("|")[1];
            var point = new BMap.Point(p0,p1);
			var iconImg = createIcon(json.icon);
            var marker = new BMap.Marker(point,{icon:iconImg});
			var iw = createInfoWindow(i);
			var label = new BMap.Label(json.title,{"offset":new BMap.Size(json.icon.lb-json.icon.x+10,-20)});
			marker.setLabel(label);
            map.addOverlay(marker);
            label.setStyle({
                borderColor:"#808080",
                color:"#333",
                cursor:"pointer"
            });
			
			(function(){
				var index = i;
				var _iw = createInfoWindow(i);
				var _marker = marker;
				_marker.addEventListener("click",function(){
				    this.openInfoWindow(_iw);
			    });
			    _iw.addEventListener("open",function(){
				    _marker.getLabel().hide();
			    })
			    _iw.addEventListener("close",function(){
				    _marker.getLabel().show();
			    })
				label.addEventListener("click",function(){
				    _marker.openInfoWindow(_iw);
			    })
				if(!!json.isOpen){
					label.hide();
					_marker.openInfoWindow(_iw);
				}
			})()
        }
    }
    //创建InfoWindow
    function createInfoWindow(i){
        var json = markerArr[i];
        var iw = new BMap.InfoWindow("<b class='iw_poi_title' title='" + json.title + "'>" + json.title + "</b><div class='iw_poi_content'>"+json.content+"</div>");
        return iw;
    }
    //创建一个Icon
    function createIcon(json){
        //http://api.map.baidu.com/lbsapi/creatmap/images/us_mk_icon.png
        //http://app.baidu.com/map/images/us_mk_icon.png
        var icon = new BMap.Icon("http://api.map.baidu.com/lbsapi/creatmap/images/us_mk_icon.png", new BMap.Size(json.w,json.h),{imageOffset: new BMap.Size(-json.l,-json.t),infoWindowOffset:new BMap.Size(json.lb+5,1),offset:new BMap.Size(json.x,json.h)})
        return icon;
    }
    
    initMap();//创建和初始化地图

  },
};
</script>

<style scoped>
.crumbs {
  background-color: #fff;
}

.ambitus {
  width: 100%;
  /* background-color: #efefed; */
}

.lianxi {
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding-bottom: 65px;
}
.lianxi .lianxileft {
  width: 820px;
}
.lianxi .lianxileft .jieshao > span {
  font-size: 30px;
  color: #000000;
  font-weight: 400;
}
.lianxi .lianxileft .jieshao > p {
  font-size: 18px;
  color: #000000;
  margin-top: 20px;
  line-height: 30px;
  text-align: justify;
}
.lianxi .lianxileft .jieshao > .list {
  margin-top: 20px;
  display: flex;
  align-items: center;
}
.lianxi .lianxileft .jieshao > .list > span {
  font-size: 18px;
  color: #000000;
  font-weight: 400;
}
.lianxi .lianxileft .jieshao > .list > p {
  font-size: 18px;
  color: #000000;
}

.lianxi .lianxiright {
    width: 500px;
    background-color: #efefed;
    padding: 30px 0 50px;
}
.lianxi .lianxiright .lianxi_form{
    width: 400px;
    margin: auto;
}
.lianxi .lianxiright .lianxi_form .xinxi span{
    font-size: 30px;
    color: #000000;
    font-weight: 400;
}
.lianxi .lianxiright .lianxi_form .xinxi p{
    font-size: 18px;
    color: #5f5f5f;
    margin-top: 10px;
}
.inpform{
    margin-top: 10px;
}
.inpform .inplist{
    margin-top: 20px;
}
.inpform .inplist >p{
    font-size: 18px;
    color: #000000;
    display: block;
}
.inpform .inplist .inp{
    width: 100%;
    height: 60px;
    border: 1px solid #9f9f9f;
    box-sizing: border-box;
    position: relative;
    background: #fff;
    margin-top: 15px;
}
.inpform .inplist .inp>input{
    width: 100%;
    height: 100%;
    border: none;
    outline: none;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
    padding: 0 20px;
    box-sizing: border-box;
    font-size: 18px;
    color: #000000;
    background: rgba(0, 0, 0, 0);
}
.inpform .inplist .inp>p{
    position: absolute;
    left: 20px;
    top: 0;
    line-height: 60px;
    z-index: 1;
    font-size: 18px;
    color: #ff1414;
}

.inpform .inplist .inptext{
    width: 100%;
    height: 130px;
    border: 1px solid #9f9f9f;
    box-sizing: border-box;
    position: relative;
    background: #fff;
     margin-top: 15px;
}
.inpform .inplist .inptext textarea{
    width: 100%;
    height: 100%;
    border: none;
    outline: none;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
    padding: 10px 20px;
    box-sizing: border-box;
    font-size: 18px;
    color: #000000;
    background: rgba(0, 0, 0, 0);
    resize: none;
}
.inpform .inplist .inptext>p{
    position: absolute;
    left: 20px;
    top: 0;
    line-height: 60px;
    z-index: 1;
    font-size: 18px;
    color: #ff1414;
}
textarea::-webkit-scrollbar {
        /*隐藏滚动条*/
        display: none;
}
.shuzi{
    float: right;
    font-size: 14px;
    color: #5f5f5f;
    font-family: Arial;
    margin-top: 10px;
}
.inpform .tijiao{
    width: 100%;
    height: 60px;
    line-height: 60px;
    text-align: center;
    background-color: #d5b08b;
    font-size: 20px;
    color: #fff;
    cursor: pointer;
    margin-top: 30px;
}

.ditu {
  width: 820px;
  height: 300px;
  margin-top: 30px;
}
/* 地图 */
.iw_poi_title {
  color: #cc5522;
  font-size: 14px;
  font-weight: bold;
  overflow: hidden;
  padding-right: 13px;
  white-space: nowrap;
}
.iw_poi_content {
  font: 12px arial, sans-serif;
  overflow: visible;
  padding-top: 4px;
  white-space: -moz-pre-wrap;
  word-wrap: break-word;
}
</style>