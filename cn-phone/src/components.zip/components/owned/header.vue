<template>
    <div class="header" id="header">
        <!-- 公共头部 -->
        <div class="header_head">
            <div class="header_logo">
                <!-- <img src="../../assets/img/head_logo.png" alt=""> -->
                <img src="../../assets/img/logotop.png" alt="">
            </div>
            <div class="head_operation">
                <!-- <div class=""></div> -->
                <div class="huiyuan">
                    <img class="huiyuanimg" src="../../assets/img/huiyuan.png" alt="">
                    <p>王先生王先生王先生</p>
                </div>
                <div class="header_menu" v-if="!menushow" @click="kai()">
                    <img  src="../../assets/img/menuk.png" alt="">
                </div>
                 <div class="header_menu" v-if="menushow" @click="guan()">
                    <img  src="../../assets/img/menug.png" alt="">
                </div>
            </div>
        </div>
        <div class="menu" v-if="menushow">
            <div class="menutop">
                <div class="menulist menulistone">
                    <img class="pinretu" src="../../assets/img/pinretu.png" alt="">
                    <p>返回品牌页</p>
                </div>
                <div class="menulist">
                    <p>酒店与度假酒店</p>
                </div>
                <div class="menulist">
                    <p>住宿</p>
                </div>
                <div class="menulist">
                    <p>餐饮</p>
                </div>
                <div class="menulist">
                    <p>宴会</p>
                </div>
                <div class="menulist">
                    <p>体验</p>
                </div>
                <div class="menulist">
                    <p>世纪会</p>
                </div>
            </div>
            <div class="yuyan">
                <div class="yuyans  yuyanone" @click="yuyan()">
                    <div class="diqiu"><img src="../../assets/img/diqiu.png" alt=""></div>
                    <p>中文</p>
                    <div class="anniu" :class="{active:yuyanshow}">
                        <img src="../../assets/img/xialag.png" alt="">
                    </div>
                </div>
                <div class="yuyans yuyantwo" v-if="yuyanshow" @click="yuyan()">
                    <div class="diqiu"></div>
                    <p>English</p>
                </div>
            </div>
            <div class="lgins">
                <div class="lgins_btn">注册</div>
                <div class="lgins_btn">登录</div>
            </div>
        </div>
        
    </div>
</template>

<script>
    export default {
        data() {
            return {
                // meau:['酒店与度假酒店','住宿','餐饮','宴会','体验','世纪会'],
                // isTrue:1,
                isTrue: localStorage.getItem("istrue"),
                denglv:0,
                menushow:false,
                yuyanshow:false,

            };
        },

        created() {

            // localStorage.getItem("loginfou")
            // console.log(localStorage.getItem("loginfou"))
            // // loginfou
            // if( localStorage.getItem("loginfou")=='1'){
            //     this.denglv=true
            // }
            this.diaoyong()
        },
        methods: {
            kai(){
              this.menushow=true  
            },
            guan(){
              this.menushow=false  
            },
            yuyan(){
                this.yuyanshow=!this.yuyanshow
            },









            login(){
                localStorage.setItem("loginfou", 1);
                console.log(localStorage.getItem("loginfou"))
                 this.diaoyong()
            },
            restigc(){
                localStorage.setItem("loginfou", 2);
                this.diaoyong()
            },
            diaoyong(){
                // console.log(localStorage.getItem("loginfou"))
                // this.denglv = localStorage.getItem("loginfou")
                // if(localStorage.getItem("loginfou")=="0"){
                //     this.denglv=true
                // }else{
                //     this.denglv=false
                // }
                this.denglv= localStorage.getItem("loginfou")
            },
            // skip() {
			// 	// this.isTrue = 1
			// 	// this.$router.push('/aisle?date' + Date.now());
			// 	localStorage.setItem("istrue", this.isTrue);
			// },
            //头部菜单切换
            menu(index){
                this.isTrue =index
                if(index==1){
                    this.$router.push('/hotel?date' + Date.now());
                }
                if(index==2){
                    this.$router.push('/rooms?date' + Date.now());
                }
                if(index==3){
                    this.$router.push('/meal?date' + Date.now());
                }
                if(index==4){
                    this.$router.push('/banquet?date' + Date.now());
                }
                if(index==5){
                    this.$router.push('/century?date' + Date.now());
                }
                if(index==6){
                    this.$router.push('/ambitus?date' + Date.now());
                }
                localStorage.setItem("istrue", this.isTrue);
            },
            //返回品牌页
            pinpai(){
                this.$router.push('/');
            },
            //去集团官网
            jituan(){
                
            },
            //点击立即预定去房型列表页
            yuding(){
               	this.$router.push('/roomslist'); 
            },
            //点击关闭登录注册弹窗
            guanbi(){
                localStorage.setItem("loginfou", 0);
                // this.denglv = false
                // localStorage.setItem("loginfou", 0);
                console.log(this.denglv)
                this.diaoyong()
            },
            btns1(){
                this.denglv=1
                localStorage.setItem("loginfou", 1);
                this.diaoyong()
            },
            btns2(){
                this.denglv=2
                localStorage.setItem("loginfou", 2);
                this.diaoyong()
            },
        },

    };
</script>
<style scoped>
    .header{
        width: 100%;
        /* height: 140px; */
        height: 14.667vw;
    }
    .header .header_head{
        width: 89.333vw;
        width: 100%;
        padding: 0 5.333vw;
        box-sizing: border-box;
        height: 14.667vw;
        position: fixed;
        z-index: 999;
        top: 0;
        left: 0;
        background-color: #fff;
        margin: auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .header .header_head .header_logo{
        width: 33.200vw;
        height: 5.733vw;
    }
    .header .header_head .header_logo img{
        width: 100%;
        display: block;
    }
    .header .header_head .head_operation{
        /* margin-top: 13px; */
        /* margin-left: 60px; */
        /* display: flex;
        justify-content: space-between;
        flex: 1; */
        display: flex;
    }
    
    .header .header_head .head_operation .huiyuan{
        display: flex;
        align-items: center;
        margin-right: 7.333vw;
    }
    .header .header_head .head_operation .huiyuan .huiyuanimg{
        width: 4.800vw;
        height: 4.800vw;
    }
    .huiyuan p{
        width: 14vw;
        font-size: 3.5vw;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        display: block;
        margin-left: 2vw;
        color: #0e1c2d;
    }
    .header .header_head .head_operation .header_menu{
        width: 5.867vw;
        height: 4.533vw;
    }
    .header .header_head .head_operation .header_menu img{
        width: 100%;
        height: 100%;
    }
    .menu{
        width: 100%;
        height: calc(100% - 14.667vw);
        position: fixed;
        z-index: 99;
        top: 14.667vw;
        left: 0;
        background-color: #efefed;
        overflow-y: scroll;
        /* padding-top: 14.667vw; */
    }
    .menutop .menulist{
        width: 100%;
        height: 14.667vw;
        display: flex;
        align-items: center;
        padding: 0 8vw;
        box-sizing: border-box;
        border-top: 1px solid #efefed;
        background: #fff;
    }
    
    .menutop .menulist p{
        font-size: 5vw;
        color: #000;
    }

    .menutop .menulist.menulistone{
        background-color: #d5b08b;
        border: none;
    }

    .menutop .menulist.menulistone p{
        margin-left: 2.533vw;
        color: #fff;
    }
    .menutop .menulist.menulistone .pinretu{
        width: 3.867vw;
        height: 3.333vw;
    }
    .yuyan .yuyans{
        display: flex;
        height: 14.667vw;
        align-items: center;
        padding: 0 8vw;
        box-sizing: border-box;

    }
    .yuyan .yuyans .diqiu{
        width: 3.867vw;
        height: 3.867vw;
        margin-right: 6.000vw;
    }
    .yuyan .yuyans .diqiu img{
        width: 100%;
        display: block;
    }
    .yuyan .yuyans .anniu{
        width: 3.067vw;
        height: 1.600vw;
        margin-left: auto;
        transform: rotate(-90deg);
        transition: all 0.3s;
    }
    .yuyan .yuyans .anniu.active{
        transform: rotate(0);
    }
    .yuyan .yuyans .anniu img{
        width: 100%;
        display: block;
    }
    .yuyan .yuyans  p{
        color: #666666;
        font-size: 5vw;
    }
    .yuyans.yuyanone{
        border-bottom: 0.133vw solid #fff;
    }
    .yuyans.yuyantwo{
        background-color: #e1e1e1;
        /* border-top: 0.133vw solid #fff; */
    }

    .lgins{
        width: 100%;
        padding: 0 8vw;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        margin: 10.667vw 0;
    }
    .lgins .lgins_btn{
        width: 38.667vw;
        height: 10.667vw;
        background-color: #d5b08b;
        font-size: 5vw;
        color: #fff;
        text-align: center;
        line-height: 10.667vw;
    }
</style>