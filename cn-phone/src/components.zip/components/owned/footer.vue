<template>
    <!-- <div> -->
        <div class="footer" @click="fotshow=false">
            <div class="shiji">
                <div class="shiji_logo"><img src="../../assets/img/shijilogo.png" alt=""></div>
                <p class="jiaru">加入世纪会体验我们为您提供贴心贴意的服务</p>
            </div>
            <div class="footer_bottom">
                <div class="bottom_right">
                    <div class="guanzhu">
                        <p>关注我们：</p>
                        <div class="guan guan1">
                            <!-- <div class="xian xian1"></div> -->
                            <a href="https://weibo.com/u/2707064745"><img src="../../assets/img/weibo.png" alt=""></a>
                        </div>
                        <div class="guan guan2">
                            <img src="../../assets/img/weixin.png" alt="">
                            <div class="xian">
                                <img src="../../assets/img/erweima.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="switch" @click.stop="select()" >
                        <div class="switch_wen"><p>选择其他酒店</p><img src="../../assets/img/botxia.png" :style="fotshow?'transform: rotate(180deg)':''" alt=""></div>
                        <div class="chooise" v-show="fotshow">
                            <div class="chooise-scrollbar" >
                                <div class="chooise-scrollbar_wrap">
                                    <ul class="chooise_list">
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                        <li class="chooise_list_item ">
                                            <span>世纪金源大饭店一号</span>
                                        </li>
                                    </ul>

                                </div>
                            </div>
                            <!-- <div class="chooise_popper__arrow"></div> -->

                        </div>
                    </div>
                </div>
                <div class="bottom_left">
                    <div class="bot_top">
                        <p @click="pages(1)">世纪会</p>
                        <p @click="pages(2)">媒体中心</p>
                        <p @click="pages(3)">联系我们</p>
                        <p @click="pages(4)">法律声明</p>
                    </div>
                    <div class="bot_cen">
                        <p>地址 : 北京市海淀区板井路69号</p>
                        <p>邮政编码 : 100097</p>
                        <p>总机 : 010-88598888</p>
                        <p>传真 : 010-88599999</p>
                    </div>
                    <div class="bot_fot">
                        <p>© 2022 世纪金源大饭店 保留所有权利</p>
                        <br>
                        <p>京ICP备08002619号-1</p>

                        <p>京公网安备11010802015160</p>
                    </div>
                </div>
                
            </div>
        </div>
    <!-- </div> -->
</template>

<script>
    export default {
        data() {
            return {
                fotshow:false
            };
        },

        created() {
            // this.user = localStorage.getItem("user");
            // console.log(this.user);
        },

        methods: {
            pages(index){
                if(index==1){
                    this.$router.push("/ambitus?date" + Date.now());
                }
                if(index==2){
                    this.$router.push("/media?date" + Date.now());
                }
                if(index==3){
                    this.$router.push("/contact?date" + Date.now());
                }
                if(index==4){
                    this.$router.push("/law?date" + Date.now());
                }
            },
            // damage() {
            //     //上传箱损
            //     this.$router.push("/demo?date" + Date.now());
            // },
            // license() {
            //     //上传车牌
            //     this.$router.push("/Licenseplate?date" + Date.now());
            // },
            // casen() {
            //     //上传箱号
            //     this.$router.push("/casen?date" + Date.now());
            // },
            //底部选择
            select(){
                this.fotshow = !this.fotshow
            },
        },

    };
</script>
<style scoped>
    .footer{
        padding-bottom: 4vw;
    }
    .footer .shiji {
        width: 100%;
        height: 32.000vw;
        background: linear-gradient(to bottom, #efece7 40%, #f7f6f3 60%, #fff);
        border-bottom: 0.133vw solid #dae4e4;
    }

    .footer .shiji .shiji_logo {
        width: 16.267vw;
        height: 11.467vw;
        margin: auto;
        text-align: center;
        padding-top: 6.000vw;
    }

    .footer .shiji .shiji_logo img {
        width: 100%;
        height: 100%;
        display: block;
    }

    .footer .shiji .jiaru {
        text-align: center;
        margin: auto;
        font-size: 3.2vw;
        color: #a8916f;
        display: table;
        border-bottom: 0.133vw solid #a8916f;
        cursor: pointer;
        margin-top: 4.000vw;
    }

    .footer .footer_bottom {
        width: 89.333vw;
        margin: auto;
        box-sizing: border-box;
    }

    .footer .footer_bottom .bottom_left{
        margin-top: 8.000vw;
    }
    .footer .footer_bottom .bottom_left .bot_top {
        display: flex;
        font-size: 3.2vw;
        color: #5f5f5f;
    }

    .footer .footer_bottom .bottom_left .bot_top p {
        margin-right: 4.000vw;
        cursor: pointer;
    }

    .footer .footer_bottom .bottom_left .bot_cen {
        font-size: 3.2vw;
        color: #5f5f5f;
        margin: 2vw 0;
    }

    .footer .footer_bottom .bottom_left .bot_cen p {
        display: inline-block;
        margin-right: 1.600vw;
    }

    .footer .footer_bottom .bottom_left .bot_fot {
        font-size: 2.6vw;
        color: #5f5f5f;
    }

    .footer .footer_bottom .bottom_left .bot_fot p {
        margin-right: 0.667vw;
        display: inline-block;
    }

    .footer .footer_bottom .bottom_right{ 
        display: flex;
        margin-top: 3.333vw;
        justify-content: space-between;
        align-items: center;
        
    }
    .footer .footer_bottom .bottom_right .guanzhu {
        display: flex;
        height: 100%;
        align-items: center;
    }

    .footer .footer_bottom .bottom_right .guanzhu p {
        font-size: 3.2vw;
        color: #5f5f5f;
    }

    .footer .footer_bottom .bottom_right .guanzhu .guan {
        width: 5.600vw;
        cursor: pointer;
        position: relative;
        margin-left: 2.667vw;
        width: 5.333vw;
        height: 4.533vw;
    }

    .footer .footer_bottom .bottom_right .guanzhu .guan img {
        width: 100%;
    }

    .footer .footer_bottom .bottom_right .guanzhu .guan .xian {
        background-color: #fff;
        padding: 3vw;
        border-radius: 2vw;
        width: 13.333vw;
        height: 13.333vw;
        position: absolute;
        top: -21.333vw;
        left: 50%;
        margin-left: -8.667vw;
        display: none;
        /* box-shadow: 0 4px 20px 0 rgb(0, 0, 0, 0.07); */
       box-shadow: 0 0.533vw 2.667vw 0 rgba(0, 0, 0, .07);
    }
    .footer .footer_bottom .bottom_right .guanzhu .guan1 a{
        width: 100%;
        height: 100%;
        display: block;
    }

    .footer .footer_bottom .bottom_right .guanzhu .guan2:hover>.xian {
        display: block;
    }

    /* .chooise */
    .footer .footer_bottom .bottom_right .switch {
        width: 30.067vw;
        height: 7.6vw;
        box-sizing: border-box;
        border: 0.133vw solid #c5c5c5;
        position: relative;
        /* margin-top: 5.600vw; */

    }
    .footer .footer_bottom .bottom_right .switch .switch_wen{
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        height: 100%;
        padding: 0 2.133vw 0 3.467vw;
        box-sizing: border-box;
        cursor: pointer;
    }
    .footer .footer_bottom .bottom_right .switch .switch_wen p{
        font-size: 3vw;
        color: #5f5f5f;
    }
    .footer .footer_bottom .bottom_right .switch .switch_wen img{
        width: 1.934vw;
        height: 1vw;
    }
   

    .footer .footer_bottom .bottom_right .switch .chooise {
        position: absolute;
        z-index: 9;
        border: 0.133vw solid #e4e7ed;
        border-radius: 0.533vw;
        background-color: #fff;
        /* box-shadow: 0 0.267vw 1.600vw 0 rgb(0 0 0 / 10%); */
        box-shadow: 0 0.533vw 2.667vw 0 rgba(0, 0, 0, .07);
        box-sizing: border-box;
        margin: 0.667vw 0;
        min-width: 40.000vw;
        transform-origin: center top;
        bottom: 8vw;
        right: 0;
        /* display: none; */
    }
    .footer .footer_bottom .bottom_right .switch .chooise.active{
        display: block;
    }

    .chooise-scrollbar {
        overflow: hidden;
        position: relative;
    }

    .chooise-scrollbar_wrap {
        overflow: scroll;
        /* height: 100%; */
        margin-bottom: -2.267vw;
        margin-right: -2.267vw;
        max-height: 32.000vw;
    }

    .chooise_list {
        list-style: none;
        padding: 0.800vw 0;
        margin: 0;
        box-sizing: border-box;
    }

    .chooise_list_item {
        font-size: 3.2vw;
        padding: 0 2.667vw;
        position: relative;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        color: #606266;
        height: 5.333vw;
        line-height: 5.333vw;
        box-sizing: border-box;
        cursor: pointer;
    }

    .chooise_list_item.selected {
        color: #409eff;
        font-weight: 700;
    }
    .chooise_list_item:hover{
        background-color: #f5f7fa;
    }
        








    /* .chooise_popper__arrow {
        position: absolute;
    display: block;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
        top: -10px;
        left: 50%;
        margin-right: 3px;
        border-top-width: 0;
        border-bottom-color: #ebeef5;
        border-width: 6px;
    filter: drop-shadow(0 2px 12px rgba(0,0,0,.03));
        
    }
    .chooise_popper__arrow::after {
        position: absolute;
    display: block;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
    border-width: 6px;
    filter: drop-shadow(0 2px 12px rgba(0,0,0,.03));
        top: 1px;
        margin-left: -6px;
        border-top-width: 0;
        border-bottom-color: #fff;
    }
    .a{
        min-width: 240px;
    transform-origin: center top;
    z-index: 2076;
    position: absolute;
    top: 425px;
    left: 366px;
    } */
</style>