<template>
    <div class="container">


        <div class="conts">
            <div class="login">
                <div class="login_logo">
                    <img src="../../assets/img/head_logo.png" alt="">
                </div>
                <div class="logs">
                    <div class="txt_title">
                        <div class="" :class="denglv==1?'active':''" @click="btns1()">会员登录</div>
                        <div class="" :class="denglv==2?'active':''" @click="btns2()">会员注册</div>
                    </div>
                    <div class="fomes1" v-if="denglv==1">
                        <div class="fomes1list">
                            <span>账号：</span>
                            <input type="text" placeholder="请输入手机号">
                        </div>
                        <div class="fomes1list">
                            <span>密码：</span>
                            <input type="text" placeholder="请输入密码">
                        </div>
                        <div class="fomes1list">
                            <div class="de">登录</div>
                        </div>
                        <div class="fomes1list fomes1listp">
                            <p class="wenzi">登录可享：预定折扣、积分奖励、会员专享礼遇</p>
                        </div>
                    </div>
                  
                    <!-- wenzijiayouaoligejiyjiajiayouaoligejiyjiayouaoligejiuzhelijiayouaoli -->
                    <div class="fomes2"  v-if="denglv==2">
                        <div class="fomes2list">
                            <span>输入手机号：</span>
                            <input class="inp2list" type="text" >
                        </div>
                        <div class="fomes2list">
                            <span>请输入验证码：</span>
                            <div class="fors2sky">
                                <input class="inpyanma" type="text" >
                                <div class="yanma">发送验证码</div>
                            </div>
                        </div>
                        <div class="fomes2list">
                            <span>密码：</span>
                            <input class="inp2list" type="text" >
                        </div>
                        <div class="fomes2list">
                            <span>确认密码：</span>
                            <input class="inp2list" type="text" >
                        </div>
                        <div class="fomes2list">
                            <div class="zhu">注册</div>
                        </div>
                    </div>
                    
                </div>
                <div class="zhanwei" v-if="denglv==1"></div>
            </div>
        </div>

    </div>
</template>

<script>

    export default {
        components: {
        },
        data() {
            return {
               denglv:1, 
            };
        },

        created() {
        },
        methods: {
            btns1(){
                this.denglv=1
                // localStorage.setItem("loginfou", 1);
                // this.diaoyong()
            },
            btns2(){
                this.denglv=2
                // localStorage.setItem("loginfou", 2);
                // this.diaoyong()
            },
             

        },

    };
</script>
<style scoped>
/* body{
    background-color: #efefed !important;
} */
    .conts{
        width: 100%;
        /* height: 100vh; */
        background-color: #efefed;
    }

    .login{
        width: 100%;
        margin: auto;
        margin-top: 12.933vw;
        /* background-color: #fff; */
        position: relative;
        padding-bottom: 7.333vw;
    }
    
    .login_logo{
        width: 21.333vw;
        margin: auto;
        padding-top: 3.333vw;
    }
    .login_logo img{
        width: 100%;
        display: block;
       
    }
    .logs{
        width: 89.333vw;
        background-color: #fff;
        padding-bottom: 10.000vw;
        margin: auto;
        box-shadow: 0px 0px 2px 3px #000;
        border-radius: 2vw;
        overflow: hidden;
        margin-top: 12.267vw;
        box-shadow: 0px 0px 9px 1px #d4d2d2;
        
    }
    .txt_title{
        display: flex;
        align-items: center;
    }
    .txt_title div{
        width: 50%;
        height: 12.667vw;
        background-color: #f2f2f2;
        font-size: 4.5vw;
        color: #9f9f9f;
        text-align: center;
        line-height: 12.667vw;
        cursor: pointer;
    }
    .txt_title div.active{
        background-color: #d5b08b;
        color: #fff;
    }
    .fomes1{
        margin: auto;
        padding: 0 9.333vw;
        /* padding-top: 3.333vw; */
    }
    .fomes1 .fomes1list{
        margin-top: 3.667vw;
        /* display: flex;
        align-items: center; */
    }
    .fomes1 .fomes1list span{
        font-size: 4vw;
        color: #000000;
        display: block;
    }
    .fomes1 .fomes1list input{
        width: 70.667vw;
        height: 12.000vw;
        border: none;
        border-radius: 2vw;
        background-color: #f6f6f6;
        outline: none;
        padding: 0 4.667vw;
        font-size: 3.5vw;
        color: #989898;
        box-sizing: border-box;
        margin-top: 3.333vw;
    }
    .fomes1 .fomes1list .de{
        width: 70.667vw;
        height: 12.000vw;
        background-color: #d5b08b;
        color: #fff;
        text-align: center;
        line-height: 12.000vw;
        font-size: 4.5vw;
        border-radius: 2vw;
        margin-top: 6.667vw;
    }
    .fomes1 .fomes1list.fomes1listp{
        margin-top: 2.5vw;
    }
    .fomes1 .fomes1list .wenzi{
        font-size: 3vw;
        text-align: center;
        color: #5f5f5f;
    }
    .fomes2{
        margin: auto;
        padding: 0 9.333vw;
    }
    .fomes2 .fomes2list{
        margin-top: 3.667vw;
    }
    .fomes2 .fomes2list span{
        font-size: 4vw;
        color: #000000;
        display: block;
    }
    .fomes2 .fomes2list .inp2list{
        width: 70.667vw;
        height: 12.000vw;
        border: none;
        border-radius: 2vw;
        background-color: #f6f6f6;
        outline: none;
        padding: 0 4.667vw;
        font-size: 3.5vw;
        color: #989898;
        box-sizing: border-box;
        margin-top: 3.333vw;
    }
    .fomes2 .fomes2list .fors2sky{
        width: 70.667vw;
        height: 12.000vw;
        border: none;
        border-radius: 2vw;
        background-color: #f6f6f6;
        box-sizing: border-box;
        margin-top: 4.333vw;
        overflow: hidden;
        display: flex;
    }
    .fomes2 .fomes2list .fors2sky .inpyanma{
        width: 48.000vw;
        height: 12.000vw;
        border: none;
        outline: none;
        padding: 0 4.667vw;
        font-size: 3.5vw;
        color: #989898;
        box-sizing: border-box;
        background-color: #f6f6f6;
    }
    .fomes2 .fomes2list .fors2sky .yanma{
        width: 22.667vw;
        height: 12.000vw;
        background-color: #f2f2f2;
        font-size: 3.5vw;
        line-height: 12.000vw;
        color: #206079;
        text-align: center;
    }
    .fomes2 .fomes2list .zhu{
         width: 70.667vw;
        height: 12.000vw;
        background-color: #d5b08b;
        color: #fff;
        text-align: center;
        line-height: 12.000vw;
        font-size: 4.5vw;
        border-radius: 2vw;
        margin-top: 6.667vw;
    }
    .zhanwei{
        height: 48vw;
    }

</style>