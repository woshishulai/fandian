<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />
        <!-- 日历 -->
        <Queryhotel />
        <div class="conts">
            <!-- 头部条 -->
            <div class="conts_top">
                <img src="../../assets/img/zhan1.jpg" alt="">
                <p>房型展示</p>
            </div>
            <!-- 第一块房子 -->
            <div class="room_type">
                <div class="main">
                    <div class="type_left">
                        <div class="type_left_list" @click="roomdeatil()">
                            <div class="left_img">
                                <img src="../../assets/img/room1.jpg" alt="">
                            </div>
                            <div class="tit">1.8米水景大床房</div>
                            <div class="type_left_text">
                                客房内置侨派装饰家具和现代化生活设施，配备智能电视、胶囊咖啡机、私人保险箱、迷你吧、无线网络及全面覆盖的5G网络信号、法国欧珑
                            </div>
                            <div class="detail">查看详细</div>
                        </div>
                    </div>
                    <div class="type_right">
                        <div class="type_right_list clearfix" @click="roomdeatil()">
                            <div class="right_img">
                                <img src="../../assets/img/room2.jpg" alt="">
                            </div>
                            <div class="tit">1.8米水景大床房</div>
                            <div class="detail">查看详细</div>
                        </div>
                        <div class="type_right_list clearfix" @click="roomdeatil()">
                            <div class="right_img">
                                <img src="../../assets/img/room2.jpg" alt="">
                            </div>
                            <div class="tit">1.8米水景大床房</div>
                            <div class="detail">查看详细</div>
                        </div>
                        <div class="type_right_list clearfix" @click="roomdeatil()">
                            <div class="right_img">
                                <img src="../../assets/img/room2.jpg" alt="">
                            </div>
                            <div class="tit">1.8米水景大床房</div>
                            <div class="detail">查看详细</div>
                        </div>
                        <div class="type_right_list clearfix" @click="roomdeatil()">
                            <div class="right_img">
                                <img src="../../assets/img/room2.jpg" alt="">
                            </div>
                            <div class="tit">1.8米水景大床房</div>
                            <div class="detail">查看详细</div>
                        </div>
                    </div>
                </div>
                <div class="room_more" @click="roomlist()">
                    <img src="../../assets/img/jia.png" alt="">
                    <p>更多房型</p>
                </div>
            </div>
            <!-- 第二块 健身... -->
            <div class="bodybuild">
                <div class="body_back">
                    <img src="../../assets/img/room3.jpg" alt="">
                    <img src="../../assets/img/hotel6.jpg" alt="">
                    <img src="../../assets/img/hotel62.jpg" alt="">
                </div>
                <div class="body_hua">
                    <div class="body_hua_left">
                        <div class="body_hua_list ">
                            <img src="../../assets/img/kongjian.png" alt="">
                            <p>空间</p>
                        </div>
                        <div class="body_hua_list">
                            <img src="../../assets/img/yaling.png" alt="">
                            <p>健身</p>
                        </div>
                        <div class="body_hua_list">
                            <img src="../../assets/img/kafei.png" alt="">
                            <p>云顶</p>
                        </div>
                    </div>
                    <div class="body_hua_right">
                        <div class="body_text_list">
                            <div class="biaoti">空间</div>
                            <div class="jianjie">
                                位于酒店5层，健身房外营造了花园景观，在优美的氛围中，为乐活人士提供放松身心的健身体验。现代化的健身房引入齐备的先进设施，恒温无边泳池更增运动乐趣，自在畅游，焕活身心
                            </div>
                            <div class="lianxi">
                                <p>健身房营业时间：24小时 </p>
                                <p>游泳池营业时间：07:00至22:00</p>
                                <p>电话：+86 10 6513 6666 转 6589</p>
                            </div>
                        </div>
                        <div class="body_text_list">
                            <div class="biaoti">健身</div>
                            <div class="jianjie">
                                位于酒店5层，健身房外营造了花园景观，在优美的氛围中，为乐活人士提供放松身心的健身体验。现代化的健身房引入齐备的先进设施，恒温无边泳池更增运动乐趣，自在畅游，焕活身心
                            </div>
                            <div class="lianxi">
                                <p>健身房营业时间：24小时 </p>
                                <p>游泳池营业时间：07:00至22:00</p>
                                <p>电话：+86 10 6513 6666 转 6589</p>
                            </div>
                        </div>
                        <div class="body_text_list">
                            <div class="biaoti">云顶</div>
                            <div class="jianjie">
                                位于酒店5层，健身房外营造了花园景观，在优美的氛围中，为乐活人士提供放松身心的健身体验。现代化的健身房引入齐备的先进设施，恒温无边泳池更增运动乐趣，自在畅游，焕活身心
                            </div>
                            <div class="lianxi">
                                <p>健身房营业时间：24小时 </p>
                                <p>游泳池营业时间：07:00至22:00</p>
                                <p>电话：+86 10 6513 6666 转 6589</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue"
    import Footer from "../owned/footer.vue"
    import Queryhotel from "../rooms/queryhotel.vue";
    export default {
        components: {
            Header,
            Footer,
            Queryhotel,
        },
        data() {
            return {

            };
        },

        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 2);
        },

        methods: {
            // 去房型列表页
            roomlist(){
                this.$router.push('/roomslist?date' + Date.now());
            },
            //去房型详情页
            roomdeatil(){
                this.$router.push('/roomsdetail?date' + Date.now());
            },
        },
        mounted() {
            var body_hua_list = document.querySelectorAll(".body_hua_left .body_hua_list")
            var body_text_list = document.querySelectorAll(".body_hua_right .body_text_list")
            var body_back = document.querySelectorAll(".body_back img")
            body_hua_list[1].className = "body_hua_list active"
            body_text_list[1].className = "body_text_list active"
            body_back[1].style.display = "block"
            for (let i = 0; i < body_hua_list.length; i++) {
                body_hua_list[i].index = i
                body_hua_list[i].onmouseover = function () {
                    for (let i = 0; i < body_hua_list.length; i++) {
                        body_hua_list[i].className = "body_hua_list"
                        body_text_list[i].className = "body_text_list"
                        body_back[i].style.display = "none"
                    }
                    // console.log(this.index)
                    body_hua_list[this.index].className = "body_hua_list active"
                    body_text_list[this.index].className = "body_text_list active"
                    body_back[this.index].style.display = "block"
                }
            }
        },

    };
</script>
<style scoped>

    /* 房型 */
    .room_type {
        padding: 48px 0;
    }

    .room_type .main {
        display: flex;
    }

    .room_type .type_left {
        width: 688px;
    }

    /* .room_type .type_left .type_left_list {
        display: flex;
    } */

    .room_type .type_left .type_left_list {
        cursor: pointer;
    }

    .room_type .type_left .type_left_list .left_img {
        width: 688px;
        height: 433px;
        overflow: hidden;
    }

    .room_type .type_left .type_left_list .left_img img {
        width: 100%;
        display: block;
        transition: all 0.5s;
    }

    .room_type .type_left .type_left_list .tit {
        margin-top: 15px;
        font-size: 24px;
        color: #000000;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .room_type .type_left .type_left_list .type_left_text {
        margin-top: 13px;
        font-size: 18px;
        color: #5f5f5f;
        line-height: 30px;
        height: 60px;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 2;
        /*要显示的行数*/
        -webkit-box-orient: vertical;
    }

    .room_type .type_left .type_left_list .detail {
        margin-top: 13px;
        font-size: 18px;
        color: #a8916f;
        width: 80px;
        text-align: center;
    }

    .room_type .type_left .type_left_list:hover .left_img img {
        transform: scale(1.2);
    }

    /* .room_type .type_left .type_left_list .left_img img */
    .room_type .type_right {
        margin-left: 30px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }

    .room_type .type_right .type_right_list {
        width: 328px;
        cursor: pointer;
    }

    .room_type .type_right .type_right_list .right_img {
        width: 328px;
        height: 205px;
        overflow: hidden;
    }

    .room_type .type_right .type_right_list .right_img img {
        width: 100%;
        display: block;
        transition: all 0.5s;
    }

    .room_type .type_right .type_right_list:hover .right_img img {
        transform: scale(1.2);
    }

    .room_type .type_right .type_right_list .tit {
        margin-top: 15px;
        font-size: 24px;
        color: #000000;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .room_type .type_right .type_right_list .detail {
        margin-top: 13px;
        font-size: 18px;
        color: #a8916f;
        width: 80px;
        text-align: center;
        float: right;
    }

    .room_type .type_right .type_right_list:nth-child(1) {
        margin-bottom: 10px;
    }

    .room_type .room_more {
        width: 200px;
        margin: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: 45px;
        cursor: pointer;
    }

    .room_type .room_more img {
        width: 16px;
        margin-right: 8px;

    }

    .room_type .room_more p {
        font-size: 18px;
        color: #206079;
    }

    /* 健身... */
    .bodybuild {
        width: 100%;
        height: 800px;
        position: relative;
    }

    .bodybuild .body_back {
        width: 100%;
        height: 800px;
        position: relative;
    }

    .bodybuild .body_back img {
        width: 1920px;
        height: 800px;
        position: absolute;
        top: 0;
        left: 50%;
        margin-left: -960px;
        z-index: 1;
    }

    .bodybuild .body_hua {
        position: absolute;
        width: 1400px;
        height: 100%;
        left: 50%;
        margin-left: -700px;
        top: 0;
        z-index: 2;
        color: #FFF;
        display: flex;
        align-items: center;
    }

    .bodybuild .body_hua .body_hua_left {
        display: flex;
        flex-wrap: wrap;
        width: 620px;
    }

    .bodybuild .body_hua .body_hua_left .body_hua_list {
        width: 307px;
        /* height: 317px; */
        height: 319px;
        border: 1px solid #898f8f;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background-color: rgba(255, 255, 255, .4);
        box-sizing: border-box;
        cursor: pointer;
    }

    .bodybuild .body_hua .body_hua_left .body_hua_list:nth-child(1) {
        margin-right: 10px;
    }

    .bodybuild .body_hua .body_hua_left .body_hua_list.active {
        border: 1px solid #fff;
        background-color: #d5b08b;
    }

    /* .bodybuild .body_hua .body_hua_left .body_hua_list:nth-child(1) {

        border-bottom: none;
    } */

    .bodybuild .body_hua .body_hua_left .body_hua_list img {
        width: 65px;
        height: 65px;
    }

    .bodybuild .body_hua .body_hua_left .body_hua_list p {
        font-size: 30px;
        color: #fff;
    }

    .bodybuild .body_hua .body_hua_right {
        margin-left: 135px;
        width: 647px;
    }

    .bodybuild .body_hua .body_hua_right .body_text_list {
        display: none;
    }

    .bodybuild .body_hua .body_hua_right .body_text_list.active {
        display: block;
    }

    .bodybuild .body_hua .body_hua_right .body_text_list .biaoti {
        font-size: 30px;
        color: #fff;
    }

    .bodybuild .body_hua .body_hua_right .body_text_list .jianjie {
        margin-top: 25px;
        font-size: 18px;
        color: #fff;
    }

    .bodybuild .body_hua .body_hua_right .body_text_list .lianxi {
        margin-top: 35px;
        font-size: 18px;
        color: #fff;
    }


    /* <div class="body_hua_right">
                        <div class="body_text_list ">
                            1
                            <div class="biaoti">空间</div>
                            <div class="jianjie"></div>
                            <div class="lianxi">
                                <p></p>
                            </div>
                        </div>
                        <div class="body_text_list">
                            2
                        </div>
                        <div class="body_text_list">
                            3
                        </div>
                    </div> */
</style>