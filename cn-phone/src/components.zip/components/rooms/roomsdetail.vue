<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />

        <div class="conts">
            <div class="room_detail">
                <div class="main">
                    <div class="detail_tit">1.8米水景大床房</div>
                    <div class="detailone">
                        <div class="lunbotu">
                            <div class="swiper-container-wrapper">
                                <div class="one_left">
                                    <div class="swiper-container gallery-top">
                                        <div class="swiper-wrapper">
                                            <!-- Slides -->
                                            <div class="swiper-slide">
                                                <div class="deta_leftimg">
                                                    <img src="../../assets/img/deatl1.jpg" alt="">
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_leftimg">
                                                    <img src="../../assets/img/deatl1.jpg" alt="">
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_leftimg">
                                                    <img src="../../assets/img/deatl1.jpg" alt="">
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_leftimg">
                                                    <img src="../../assets/img/deatl1.jpg" alt="">
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_leftimg">
                                                    <img src="../../assets/img/deatl1.jpg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="one_right">
                                    <!-- Add Arrows -->
                                    <div class="anniu anniu1">
                                        <div class="swiper-button-prev"></div>
                                    </div>
                                    <div class="anniu anniu2">
                                        <div class="swiper-button-next"></div>
                                    </div>

                                    <div class="swiper-container gallery-thumbs">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <div class="deta_rightimg"><img src="../../assets/img/deatl1.jpg"
                                                        alt=""></div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_rightimg"><img src="../../assets/img/deatl1.jpg"
                                                        alt=""></div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_rightimg"><img src="../../assets/img/deatl1.jpg"
                                                        alt=""></div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_rightimg"><img src="../../assets/img/deatl1.jpg"
                                                        alt=""></div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="deta_rightimg"><img src="../../assets/img/deatl1.jpg"
                                                        alt=""></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="service">
                            <div class="service_list">
                                <div class="servicetit">
                                    <p>客房概览</p>
                                    <div class="close" @click="close(1)">
                                        <p>{{close1?'关闭':'展开'}}</p>
                                        <img src="../../assets/img/jt.png" alt="" :style="close1?'transform: rotate(90deg)':'transform: rotate(-90deg)'">
                                    </div>
                                </div>
                                <div class="service_text" v-show="close1">
                                    <p>42平方米/452平方英尺</p>
                                    <p>配备空调</p>
                                    <p>此客房为无烟房</p>
                                    <p>提供连通房（部分客房）</p>
                                    <p>起居区</p>
                                    <p>隔音窗</p>
                                    <p>落地窗</p>
                                    <p>挂钩</p>
                                </div>
                            </div>
                            <div class="service_list">
                                <div class="servicetit">
                                    <p>客房设施</p>
                                    <div class="close" @click="close(2)">
                                        <p>{{close1?'关闭':'展开'}}</p>
                                        <img src="../../assets/img/jt.png" alt="" :style="close2?'transform: rotate(90deg)':'transform: rotate(-90deg)'">
                                    </div>
                                </div>
                                <div class="service_text" v-show="close2">
                                    <p>42平方米/452平方英尺</p>
                                    <p>配备空调</p>
                                    <p>此客房为无烟房</p>
                                    <p>提供连通房（部分客房）</p>
                                    <p>起居区</p>
                                    <p>隔音窗</p>
                                    <p>落地窗</p>
                                    <p>挂钩</p>
                                </div>
                            </div>
                            <div class="service_list">
                                <div class="servicetit">
                                    <p>其他</p>
                                    <div class="close" @click="close(3)">
                                        <p>{{close1?'关闭':'展开'}}</p>
                                        <img src="../../assets/img/jt.png" alt="" :style="close3?'transform: rotate(90deg)':'transform: rotate(-90deg)'">
                                    </div>
                                </div>
                                <div class="service_text" v-show="close3">
                                    <p>42平方米/452平方英尺</p>
                                    <p>配备空调</p>
                                    <p>此客房为无烟房</p>
                                    <p>提供连通房（部分客房）</p>
                                    <p>起居区</p>
                                    <p>隔音窗</p>
                                    <p>落地窗</p>
                                    <p>挂钩</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="detailtwo">
                        <div class="detailtwo_biao">
                            <p>房屋偏好</p>
                            <p>支付</p>
                            <p>价格</p>
                        </div>
                        <div class="detailtwo_area">
                            <div class="area_list">
                                <div class="pianhao">
                                    <img src="../../assets/img/bofang.png" alt="">
                                    <p>最优门市价</p>
                                </div>
                                <div class="zhifu">
                                    <p>线上支付</p>
                                </div>
                                <div class="jiage">
                                    <p>最低：1400.00 CNY</p>
                                </div>
                                <div class="yuding">
                                    <div>预定</div>
                                </div>
                            </div>
                            <div class="area_list">
                                <div class="pianhao">
                                    <img src="../../assets/img/bofang.png" alt="">
                                    <p>最优门市价含双早</p>
                                </div>
                                <div class="zhifu">
                                    <p>线上支付</p>
                                </div>
                                <div class="jiage">
                                    <p>最低：1400.00 CNY</p>
                                </div>
                                <div class="yuding">
                                    <div>预定</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue"
    import Footer from "../owned/footer.vue"
    import Swiper from "swiper";
    export default {
        components: {
            Header,
            Footer
        },
        data() {
            return {
                close1:true,
                close2:true,
                close3:true,
            };
        },

        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 2);
        },
        methods: {
            close(num){
                if(num==1){
                    this.close1 = !this.close1
                }
                if(num==2){
                    this.close2 = !this.close2
                }
                if(num==3){
                    this.close3 = !this.close3
                }
                
            }

        },
        mounted() {
            var galleryThumbs = new Swiper(".gallery-thumbs", {
                direction: "horizontal",
                // spaceBetween: 10,
                slidesPerView: 4,
                freeMode: false,
                watchSlidesVisibility: true,
                watchSlidesProgress: true,
                breakpoints: {
                    480: {
                        direction: "vertical",
                        slidesPerView: 4,
                    }
                }
            });
            var galleryTop = new Swiper(".gallery-top", {
                direction: "horizontal",
                // spaceBetween: 10,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                thumbs: {
                    swiper: galleryThumbs
                }
            });
        },

    };
</script>
<style scoped>

    .room_detail {
        width: 100%;
        background-color: #efefed;
        padding-bottom: 30px;
    }

    .detail_tit {
        font-size: 30px;
        color: #000000;
        line-height: 86px;
    }

    .detailone {
        width: 100%;
        padding: 30px 30px 0;
        box-sizing: border-box;
        background-color: #fff;
        position: relative;
    }

    /* 联动轮播图 */
    .lunbotu {
        padding-bottom: 37px;
    }

    .swiper-container-wrapper {
        display: flex;
        flex-flow: row nowrap;
        width: 100%;
        justify-content: space-between;
    }


    /* 左边的大图 */
    .gallery-top {
        width: 1113px;
        height: 776px;
    }

    .deta_leftimg {
        width: 100%;
        height: 100%;
    }

    .deta_leftimg img {
        width: 100%;
        display: block;
    }

    /* 右边的缩略图 */
    .gallery-thumbs {
        width: 200px;
        height: 612px;
    }

    .gallery-thumbs .swiper-wrapper {
        flex-direction: row;
        flex-direction: column;
    }

    .gallery-thumbs .swiper-slide {
        cursor: pointer;
        flex-flow: column nowrap;
        width: 100%;
        height: 140px !important;
        margin-bottom: 17px;
    }

    .deta_rightimg {
        width: 100%;
        height: 140px;
        /* 215 250 */
    }

    .deta_rightimg img {
        width: 100%;
        display: block;
    }

    .gallery-thumbs .swiper-slide::after {
        position: absolute;
        content: "";
        background-color: rgba(0, 0, 0, .5);
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        z-index: 2;
    }

    .gallery-thumbs .swiper-slide-thumb-active::after {
        display: none;
    }

    /* 右边箭头 */
    .one_right {
        position: relative;
        display: flex;
        align-items: center;
    }

    .anniu {
        position: absolute;
        width: 100%;
        height: 44px;
        background-color: #f2f2f2;
        left: 0;
        z-index: 2;
    }

    .anniu1 {
        top: 0;
    }

    .anniu2 {
        bottom: 0;
    }

    .swiper-button-next,
    .swiper-button-prev {
        color: #fff;
        width: 21px;
        height: 11px;
        width: 100%;
        height: 100%;
        top: 0;
        /* margin-top: -5px; */
        margin-left: 0;
        margin-top: 0;
        left: 0;
        background-image: url(../../assets/img/anniu2.png);
        background-repeat: no-repeat;
        background-size: 21px 11px;
        background-position: center;
        opacity: 1;
    }

    .swiper-button-prev {
        transform: rotate(180deg);
    }

    .swiper-button-next::after,
    .swiper-button-prev::after {
        display: none;
    }

    .swiper-button-disabled {
        background-image: url(../../assets/img/anniu1.png);
    }

    /* 设施... */
    .service {
        /* 大框 里面右三个 */
    }

    .service .service_list {
        border-top: 1px solid #d8d8d8;
        padding: 30px 0;
    }

    .service .service_list .servicetit {
        display: flex;

    }

    .service .service_list .servicetit>p {
        font-size: 24px;
        color: #000000;
        font-weight: 400;
    }

    .service .service_list .servicetit .close {
        display: flex;
        align-items: center;
        margin-left: auto;
        margin-right: 15px;
        cursor: pointer;
    }

    .service .service_list .servicetit .close>img {
        width: 9px;
        height: 17px;
        transform: rotate(90deg);
        margin-left: 12px;
    }

    .service .service_list .service_text {
        margin-top: 30px;
        display: flex;
        flex-wrap: wrap;
    }

    .service .service_list .service_text p {
        font-size: 18px;
        color: #666666;
        line-height: 32px;
        width: 290px;
        margin-left: 50px;
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .service .service_list .service_text p:nth-child(4n+1) {
        margin-left: 0;
    }

    /* 房屋偏好... */
    .detailtwo {
        margin-top: 30px;
        width: 100%;
    }

    .detailtwo_biao {
        background-color: #d5b08b;
        display: flex;
        height: 60px;
        align-items: center;
    }

    .detailtwo_biao p {
        color: #fff;
        font-size: 20px;
        margin-left: 30px;
        width: 320px;
        box-sizing: border-box;
    }

    .detailtwo_biao p:nth-child(1) {
        padding-left: 42px;
    }

    .detailtwo .detailtwo_area {
        background-color: #fff;
    }

    .detailtwo .detailtwo_area .area_list {
        display: flex;
        align-items: center;
        border-top: 1px solid #e3e3e3;
        height: 100px;
    }

    .detailtwo .detailtwo_area .area_list:first-child {
        border-top: none;
    }

    .detailtwo .detailtwo_area .area_list>div {
        margin-left: 30px;
        width: 320px;

    }

    .detailtwo .detailtwo_area .area_list .pianhao {
        display: flex;
        align-items: center;
    }

    .pianhao>img {
        width: 14px;
        height: 14px;
        display: flex;
        margin-right: 28px;
    }

    .pianhao p {
        font-size: 20px;
        color: #000000;
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .zhifu p {
        font-size: 20px;
        color: #000000;
        font-weight: 400;
    }

    .jiage p {
        font-size: 20px;
        color: #000000;
    }

    .yuding div {
        width: 200px;
        height: 50px;
        background-color: #f4f4f4;
        font-size: 20px;
        color: #206079;
        text-align: center;
        line-height: 50px;
        cursor: pointer;
    }
</style>