<template>
    <div class="container">
        <!-- 公共头部 -->
        <Header />

        <div class="conts">
            <!-- 头部条 -->
            <div class="conts_top">
                <img src="../../assets/img/zhan1.jpg" alt="">
                <p>房型展示</p>
            </div>
            <div class="roomslist">
                <div class="main">
                    <div class="roomslist_lunbo">
                        <div class="swiper-container lunroom">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="roomswi_list" @click="roomdeatil()">
                                        <div class="roomlist_img"> <img src="../../assets/img/room1.jpg" alt=""></div>
                                        <div class="roomlist_version">
                                            <div class="version_eara">
                                                <span>豪华客房豪华客房</span>
                                                <p>从这间 45
                                                    平米的房间望出去，您可以尽情俯瞰上海的城市景观。同时，房间内有一面可滑动的落地丝绸屏风，让您能随心所欲的将开放式的空间，转变成一个更为私人的处所。客房包含以下设施。
                                                </p>
                                                <div class="room_detail">查看详细</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <!-- 如果需要导航按钮 -->
                        <div class="swiper-button-prev prevroom"></div>
                        <div class="swiper-button-next nextroom"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 公共底部 -->
        <Footer />
    </div>
</template>

<script>
    import Header from "../owned/header.vue";
    import Footer from "../owned/footer.vue";
    import Swiper from "swiper";
    export default {
        components: {
            Header,
            Footer
        },
        data() {
            return {

            };
        },
        created() {
            // 储存第几个头部状态
            localStorage.setItem("istrue", 2);
        },
        methods: {

            //去房型详情页
            roomdeatil(){
                this.$router.push('/roomsdetail');
            },
        },
        mounted() {
            var lunroom = new Swiper(".lunroom", {
                // loop: true, // 循环模式选项
                // slidesPerView: 3,
                // centeredSlides: true,//这个是让第一个居中显示的
                spaceBetween: 20,
                // slidesPerView: 3,
                // 如果需要前进后退按钮
                navigation: {
                    nextEl: ".nextroom",
                    prevEl: ".prevroom",
                },

            });
        },

    };
</script>
<style scoped>
    .roomslist {
        background-color: #efefed;
    }

    /* efefed */
    .roomslist_lunbo {
        position: relative;
        /* bottom: ; */
        padding-bottom: 85px;
    }

    .prevroom,
    .nextroom {
        background-image: url(../../assets/img/xiangyou.png);
        background-size: 100%;
        background-repeat: no-repeat;
        width: 33px;
        height: 20px;
        top: 100%;
        margin-top: -50px;
    }

    .prevroom {
        transform: rotate(180deg);
    }

    .prevroom::after,
    .nextroom::after {
        display: none;
    }

    .roomswi_list {
        margin-top: 48px;
        background-color: #fff;
        display: flex;
        cursor: pointer;
    }

    .roomswi_list .roomlist_img {
        width: 576px;
        height: 363px;
        overflow: hidden;
    }

    .roomswi_list .roomlist_img img {
        width: 100%;
        display: block;
        transition: all 0.5s;
    }

    .roomlist_version {
        width: 820px;
        display: flex;
        align-items: center;
        justify-content: center;
        /* padding: 75px 80px 0; */
        box-sizing: border-box;
    }
    .roomlist_version .version_eara{
        width: 675px;
    }

    .roomlist_version .version_eara span {
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 24px;
        color: #000000;
    }

    .roomlist_version .version_eara p {
        margin-top: 35px;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        font-size: 18px;
        color: #666666;
        line-height: 32px;
        height: 65px;
    }

    .roomlist_version .version_eara .room_detail {
        margin-top: 55px;
        float: right;
        width: 125px;
        height: 40px;
        line-height: 40px;
        font-size: 18px;
        color: #a8916f;
        text-align: center;
    }

    .roomswi_list:hover {
        box-shadow: 0 0 6px 1px #d6d5d5;
    }

    .roomswi_list:hover .roomlist_img img {
        transform: scale(1.2);
    }

    .roomswi_list:hover .room_detail {
        color: #fff;
        background-color: #d5b08b;
    }
</style>