<template>
  <div class="query_hotel">
    <div class="crumbs">
      <p>您的位置：首页 > 住宿</p>
    </div>
    <div class="main">
      <div class="riqi">
        <div class="title">查找酒店</div>
        <div class="hotel_riqi">
          <!-- 时间 -->
          <div class="blocks">
            <p class="blotext">入住：</p>
            <div class="contbox checkin" @click="getrilis()">
              <p>{{wwks1}}</p>
              <img class="rilimg" src="../../assets/img/rili.png" alt="" />
            </div>
            <div id="calender" v-show="rilishow">
                <div class="calender_close" @click="guan()"><img src="../../assets/img/gunbi.png" alt=""></div>
                <div class="daterangepicker">
                  <div class="drp_calendar left">
                    <div class="drp_calendar_top">
                      <!-- ⬅️ ➡️️️️-->
                      <div @click="prev" class="prev"> 
                        <img src="../../assets/img/jt.png" alt=""> 
                      </div>
                      <span style=""> 
                        {{ year }}年{{ month }}月 
                      </span>
                      <!-- <div @click="next" class="next"> 
                        <img src="../../assets/img/jt.png" alt=""> 
                      </div> -->
                    </div>
                    <div class="weekDay week">
                      <p v-for="item in weekList" :key="item.id">{{ item }}</p>
                    </div>
                    <div class="weekDay">
                      <!-- 这个是前面的空格 -->
                      <p class="kongge" v-for="item in spaceDay" :key="item.id"></p>
                      <p class="days"
                        v-for="(item, idx) in monthDay[this.month - 1] || 30"
                        @click="setDay(idx)"
                        :class="idx == activeDay ? 'active' : ''"
                        :key="item.id"
                      >
                        {{ item }}
                      </p>
                    </div>
                  </div>
                  <div class="drp_calendar right">
                    <div class="drp_calendar_top">
                      <!-- ⬅️ ➡️️️️-->
                      <!-- <div @click="prev" class="prev"> 
                        <img src="../../assets/img/jt.png" alt=""> 
                      </div> -->
                      <span style=""> 
                        {{ year2 }}年{{ month2 }}月 
                      </span>
                      <div @click="next" class="next"> 
                        <img src="../../assets/img/jt.png" alt=""> 
                      </div>
                    </div>
                    <div class="weekDay">
                      <p class="disabled" v-for="item in weekList" :key="item.id">{{ item }}</p>
                    </div>
                    <div class="weekDay">
                      <!-- 这个是前面的空格 -->
                      <p v-for="item in spaceDay2" :key="item.id"></p>
                      <p
                        v-for="(item, idx) in monthDay2[this.month2 - 1] || 30"
                        @click="setDay2(idx)"
                        :class="idx == activeDay2 ? 'active' : ''"
                        :key="item.id"
                      >
                        {{ item }}
                      </p>
                    </div>
                  </div>
                </div>
                <div class="wancheng" @click="wancheng()">完成</div>
            </div>
          </div>
          <div class="blocks">
            <p class="blotext"> </p>
            <div class="contbox jiwan" >
              <p>14晚</p>
            </div>
          </div>
          <div class="blocks">
            <p class="blotext">退房：</p>
            <div class="contbox checkin" @click="getrilis()">
              <p>{{wwks2}}</p>
              <img class="rilimg" src="../../assets/img/rili.png" alt="" />
            </div>
          </div>
          <!-- 房间数 -->
          <div class="blocks">
            <p class="blotext">房间数量：</p>
            <div class="contbox romsnum" @click="getroom()">
              <p>{{roomIndex}}间</p>
              <img src="../../assets/img/botxia.png" alt="" :style="roomshow?'transform: rotate(180deg)':''"/>
            </div>
            <div class="roomnums" v-show="roomshow" :class="roomshow?'active':''">
              <ul>
                <li v-for="(list, index) in roomlist"
                :key="index"
                @click.stop="getnums(list)"
                :class="roomIndex == list ? 'cur' : ''">{{list}}</li>
              </ul>
            </div>
          </div>
          <!-- 人数 -->
          <div class="blocks">
            <p class="blotext">人数：</p>
            <div class="contbox peoplenum">
              <p>1间</p>
              <img src="../../assets/img/botxia.png" alt="" />
            </div>
          </div>
          <!-- 房屋偏好 -->
          <div class="blocks">
            <p class="blotext">房屋偏好：</p>
            <div class="contbox housegood">
              <p>1间</p>
              <img src="../../assets/img/botxia.png" alt="" />
            </div>
          </div>
          <!-- 公司ID -->
          <div class="blocks">
            <p class="blotext">公司ID：</p>
            <div class="contbox companyid">
              <input type="text">
              <!-- <p>1间</p> -->
              <!-- <img src="../../assets/img/botxia.png" alt="" /> -->
            </div>
          </div>
          <!-- 查询-->
          <div class="blocks">
            <p class="blotext"></p>
            <div class="contbox lookup">
              <p>查找酒店</p>
            </div>
          </div>
        </div>
        
      </div>
    </div>
    <!-- <li>日历</li> -->

    <!-- <div class="calender">
      <div class="txt-c">
        <span> - </span>
        <span>
          <input type="text" name="" id="" />
        </span>
        <span> + </span>
      </div>
    </div> -->
    <!-- a -->
  </div>
</template>

<script>
// import Header from "../owned/header.vue"
// import Footer from "../owned/footer.vue"
export default {
  // components: {
  //     Header,
  //     Footer
  // },
  data() {
    return {
      rilishow:false,
      year: "", // 年份
      month: "", // 月份
      day: "", // 天数
      current: "", // 当前时间
      weekList: ["一", "二", "三", "四", "五", "六", "日"],
      monthDay: [31, "", 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
      activeDay: "", // 选中的日期
      spaceDay: "", // 每个月第一天是星期几
      February: "", // 判断2月份的天数

wwks1:"",
wwks2:'',

      weekdate:'',
      weekdate2:'',

      year2: "", // 年份
      month2: "", // 月份
      day2: "", // 天数
      current2: "", // 当前时间
      weekList2: ["一", "二", "三", "四", "五", "六", "日"],
      monthDay2: [31, "", 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
      activeDay2: "", // 选中的日期
      spaceDay2: "", // 每个月第一天是星期几
      February2: "", // 判断2月份的天数year2: "",

      starttime:'',
      endtime:'',

      roomlist:['1','2','3','4'],//房间数量列表
      roomIndex:1,//默认一间
      roomshow:false,
    };
  },

  created() {
    this.current = new Date();
    // console.log(this.current)
        var nowDate = this.current;
    //当前月1号
    //var nowMonth = nowDate.getFullYear() + "-" + (parseInt(nowDate.getMonth() + 1) < 10 ? "0" + parseInt(nowDate.getMonth() + 1):parseInt(nowDate.getMonth() + 1)) + "-01";
    //下月1号
    var afterMonth = nowDate.getFullYear() + "-" + (parseInt(nowDate.getMonth() + 2) < 10? "0" + parseInt(nowDate.getMonth() + 2):parseInt(nowDate.getMonth() + 2)) + "-01";
    // console.log(nowMonth)
    // console.log(afterMonth)
    // console.log(new Date(afterMonth))
    this.current2 = new Date(afterMonth);

    this.getTheCurrentDate();
    this.getTheCurrentDate2();

    this.getMonthFisrtDay();
    this.getMonthFisrtDay2();

    // 调取当前年的2月天数 年份变则调用这两个
    this.February = this.isLeapYear(this.year) ? 29 : 28;
    this.monthDay.splice(1, 1, this.February);
  },
  watch: {
    month() {
      if (this.month > 12 || this.month < 1) {
        console.log("请输入正确月份");
        return;
      }
      this.getMonthFisrtDay();
      // this.getMonthFisrtDay2();
    },
    year() {
      this.getMonthFisrtDay();
    },
    month2() {
      if (this.month2 > 12 || this.month2 < 1) {
        console.log("请输入正确月份");
        return;
      }
      this.getMonthFisrtDay2();
      // this.getMonthFisrtDay2();
    },
    year2() {
      this.getMonthFisrtDay2();
    },
  },
  methods: {
    getrilis(){
      // console.log("kai")
      // console.log(this.rilishow)
      this.rilishow = true
    },
    guan(){
      // console.log("guan")
      // console.log(this.rilishow)
      this.rilishow = false
    },
    wancheng(){
      this.rilishow = false
      console.log(this.starttime)
      console.log(this.endtime)
      // this.weekdate
      // wwks1:"",
      // wwks2:'',
      console.log(this.wwks1)
      console.log(this.wwks2)

    },
    // 判断是否是闰年
    isLeapYear(year) {
      // console.log(year)
      return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
    },
    // 判断是否是闰年2
    isLeapYear2(year2) {
      // console.log(year)
      return (year2 % 4 == 0 && year2 % 100 != 0) || year2 % 400 == 0;
    },
    // 选取特定天数
    setDay(idx) {
      this.activeDay = idx;
      this.day = idx + 1;
      console.log(
        "选择的日期是" + this.year + " " + this.month + " " + this.day
      );
      var firstDayOfCurrentMonth = new Date(this.year, this.month - 1, this.day); // 某年某月的第一天
      var weekdays= 0
      if (firstDayOfCurrentMonth.getDay() == 0) {
        weekdays = 6;
      } else {
        weekdays = firstDayOfCurrentMonth.getDay() - 1;
      }
      console.log("选择的星期是：星期"+this.weekList[weekdays])
      // new Date(this.year, this.month - 1, 1)
      // starttime:'',
      // endtime:'',
      if(this.starttime==''){
        this.starttime = this.year + " " + this.month + " " + this.day
      }else if(this.starttime!=''&&this.endtime==""){
        this.endtime= this.year + " " + this.month + " " + this.day
      }else if(this.starttime!=''&&this.endtime!=''){
        this.starttime= ''
        this.endtime= ''
        this.starttime= this.year + " " + this.month + " " + this.day
      }
      this.wwks1 = "周"+this.weekList[weekdays]+","+this.year + "/" + this.month + "/" + this.day
      
    },
    // 选取特定天数2
    setDay2(idx) {
      this.activeDay2 = idx;
      this.day2 = idx + 1;
      console.log(
        "选择的日期是" + this.year2 + " " + this.month2 + " " + this.day2
      );
      var firstDayOfCurrentMonth = new Date(this.year2, this.month2 - 1, this.day2); // 某年某月的第一天
      var weekdays= 0
      if (firstDayOfCurrentMonth.getDay() == 0) {
        weekdays = 6;
      } else {
        weekdays = firstDayOfCurrentMonth.getDay() - 1;
      }
      console.log("选择的星期是：星期"+this.weekList2[weekdays])
      // new Date(this.year, this.month - 1, 1)
      if(this.starttime==''){
        this.starttime= this.year2 + " " + this.month2 + " " + this.day2
      }else if(this.starttime!=''&&this.endtime==""){
        this.endtime= this.year2 + " " + this.month2 + " " + this.day2
      }else if(this.starttime!=''&&this.endtime!=''){
        // this.starttime= ''
        this.endtime= ''
         this.starttime= this.year2 + " " + this.month2 + " " + this.day2
      }
      this.wwks2 = "周"+this.weekList2[weekdays]+","+this.year2 + "/" + this.month2 + "/" + this.day2
      
    },
    // 判断月份的第一天是星期几
    getMonthFisrtDay() {
      var firstDayOfCurrentMonth = new Date(this.year, this.month - 1, 1); // 某年某月的第一天
      if (firstDayOfCurrentMonth.getDay() == 0) {
        this.spaceDay = 6;
      } else {
        this.spaceDay = firstDayOfCurrentMonth.getDay() - 1;
      }
    },
    // 判断月份的第一天是星期几2
    getMonthFisrtDay2() {
      var firstDayOfCurrentMonth = new Date(this.year2, this.month2 - 1, 1); // 某年某月的第一天
      if (firstDayOfCurrentMonth.getDay() == 0) {
        this.spaceDay2 = 6;
      } else {
        this.spaceDay2 = firstDayOfCurrentMonth.getDay() - 1;
      }
    },
    // 获取当前的日期
    getTheCurrentDate() {
      this.year = this.current.getFullYear();
      this.month = this.current.getMonth() + 1;
      this.day = this.current.getDate();
    },
    //this.current2
    // 获取当前的日期2
    getTheCurrentDate2() {
      this.year2 = this.current2.getFullYear();
      this.month2 = this.current2.getMonth() + 1;
      this.day2 = this.current2.getDate();
    },
    prev() {
      if (this.month == 1) {
        this.year--;
        this.month = 12;
        this.February = this.isLeapYear(this.year) ? 29 : 28;
        this.monthDay.splice(1, 1, this.February);
      } else {
        this.month--;
      }
      this.activeDay = 0;
      // console.log(this.year);
      this.getMonthFisrtDay();

      if (this.month2 == 1) {
        this.year2--;
        this.month2 = 12;
        this.February2 = this.isLeapYear2(this.year2) ? 29 : 28;
        this.monthDay2.splice(1, 1, this.February2);
      } else {
        this.month2--;
      }
      this.activeDay2 = 0;
      // console.log(this.year2);
      this.getMonthFisrtDay2();
    },
    next() {
      if (this.month == 12) {
        this.year++;
        this.month = 1;
        this.February = this.isLeapYear(this.year) ? 29 : 28;
        this.monthDay.splice(1, 1, this.February);
      } else {
        this.month++;
      }
      this.activeDay = 0;
      this.getMonthFisrtDay();

      if (this.month2 == 12) {
        this.year2++;
        this.month2 = 1;
        this.February2 = this.isLeapYear2(this.year2) ? 29 : 28;
        this.monthDay2.splice(1, 1, this.February2);
      } else {
        this.month2++;
      }
      this.activeDay2 = 0;
      this.getMonthFisrtDay2();
    },



    //房间数量的选择
    getroom(){
      this.roomshow=!this.roomshow
    },
    getnums(list){
      this.roomIndex=list
      this.roomshow=false
    }
  },
  mounted() {},
};
</script>
<style scoped>
ol,
ul,
li {
  list-style: none;
}
.query_hotel {
  width: 100%;
  background-color: #efefed;
  padding-bottom: 48px;
}

.riqi {
  position: relative;
  width: 100%;
}

.riqi .title {
  font-size: 30px;
  color: #000000;
  font-weight: 400;
}
.hotel_riqi {
  margin-top: 25px;
  display: flex;
  justify-content: space-between;
}
.hotel_riqi .blocks{
  position: relative;
}
.hotel_riqi .blotext {
  font-size: 18px;
  color: #000000;
  margin-bottom: 10px;
  height: 30px;
}
.hotel_riqi .contbox {
  height: 50px;
  background-color: #fff;
  border: 1px solid #b0b0b0;
  padding-left: 19px;
  padding-right: 17px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  box-sizing: border-box;
  position: relative;
}
.hotel_riqi .contbox > p {
  font-size: 20px;
  color: #5f5f5f;
}
.hotel_riqi .contbox > img {
  width: 9px;
  height: 5px;
}


/* 日期 */
.hotel_riqi .contbox.checkin{
  width: 200px;
}
.hotel_riqi .contbox.checkin .rilimg{
  width: 16px;
  height: 17px;
  display: block;
}
/* 几晚 */
.hotel_riqi .contbox.jiwan{
  width: 70px;
  background: none;
  padding: 0;
  border: none;
  justify-content: center;
}

/* 房间数量 */
.hotel_riqi .contbox.romsnum {
  width: 110px;
}
.roomnums{
  width: 100%;
  text-align: center;
  color: #333;
  line-height: 22px;
  position: absolute;
  top: 90px;
  left: 0;
  background: #fff;
  box-shadow: 0 4px 20px 0 rgb(0,0,0,0.07);
  z-index: 9;
  /* border-radius: 15px;
  overflow: hidden; */
}
.roomnums ul{
  display: block;
  width: 100%;
}
.roomnums ul li{
  line-height: 30px;
  text-align: center;
  width: 100%;
  height: 35px;
  line-height: 35px;
  margin: auto;
  color: #000;
  font-size: 18px;
  cursor: pointer;
}
.roomnums ul li.cur{
  background: #d5b08b;
  color: #fff;
}
.roomnums ul li:hover{
  background: #ead7c3;
}

/* 人数 */
.hotel_riqi .contbox.peoplenum {
  width: 175px;
}
/* 房屋偏好 */
.hotel_riqi .contbox.housegood {
  width: 170px;
}
/* 公司ID */
.hotel_riqi .contbox.companyid {
  width: 170px;
}
.hotel_riqi .contbox.companyid input{
  width: 100%;
  height: 100%;
  /* background-color: pink; */
  background-color: #fff;
  outline: none;
  border: none;
  font-size: 20px;
  color: #5f5f5f;
}
/* 查询 */
.hotel_riqi .lookup {
  width: 200px;
  border: 1px solid #d5b08b;
  background-color: #d5b08b;
  color: #fff;
  text-align: center;
  justify-content: center;
  padding: 0;
}
.hotel_riqi .lookup p {
  color: #fff;
}

#calender {
  position: absolute;
  background-color: #fff;
  box-shadow: 0 4px 20px 0 rgb(0, 0, 0, 0.07);
  background: #fff;
  left: 0;
  top: 100px;
  padding: 0 50px;
  border-radius: 16px;
  z-index: 9;
}
#calender .calender_close{
  width: 18px;
  height: 18px;
  margin: 14px 14px 18px;
  margin-left: 100%;
}
#calender .calender_close img{
  width: 100%;
  display: block;
}
.daterangepicker{
  display: flex;
  justify-content: space-between;
  width: 810px;
}
#calender .daterangepicker .drp_calendar{
  width: 340px;
  /* width: 350px; */
  margin-top: 10px;
  min-height: 360px;
}
#calender .daterangepicker .drp_calendar.right{
  margin-left: 50px;
}
.drp_calendar .drp_calendar_top{
  position: relative;
  text-align: center;
  width: 100%;
}
.drp_calendar .drp_calendar_top span{
  display: block;
  margin: auto;
  color: #707070;
  line-height: 16px;
  font-size: 16px;
}
.drp_calendar .drp_calendar_top .prev{
  /* transform: rotate(180deg); */
  width: 9px;
  height: 17px;
  position: absolute;
  left: 0;
  top: 0;
}
.drp_calendar .drp_calendar_top .next{
  transform: rotate(180deg);
  width: 9px;
  height: 17px;
  position: absolute;
  right: 0;
  top: 0;
}
.wancheng{
    margin: 30px auto;
    width: 109px;
    height: 50px;
    line-height: 50px;
    font-size: 20px;
    text-align: center;
    color: #000000;
    border-radius: 30px;
    font-weight: 400;
    border: 1px solid #000000;
    cursor: pointer;
}
.wancheng:hover{
  background: #000000;
  color: #fff;
}
.weekDay {
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}
.weekDay p {
  text-align: center;
  position: relative;
  background: transparent;
  color: #000000;
  font-size: 14px;
  font-weight: 500;
  width: 45px;
  height: 45px;
  line-height: 45px;
  text-align: center;
  border-radius: 4px;
  border: 1px solid transparent;
  white-space: nowrap;
  /* cursor: pointer; */
}
.weekDay .days:hover {
  background-color: #eee;
  border-color: transparent;
  color: #fff;
}
.weekDay p.active {
  background-color: #d5b08b;
  color: #fff;
  border-radius: 50%;
}
.weekDay p.disabled {
    color: #999;
    /* cursor: not-allowed; */
}
.weekDay.week p {
  color: #999;
  /* cursor: not-allowed; */
}

</style>
