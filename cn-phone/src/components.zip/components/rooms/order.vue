<template>
  <div class="container">
    <!-- 公共头部 -->
    <Header />

    <div class="conts">
      <div class="crumbs">
        <p>您的位置：首页 > 订单</p>
      </div>
      <div class="order" @click="timeclose()">
        <div class="main">
          <div class="orderdetail">
            <div class="order_left">
              <div class="blocks">
                <div class="blocklist xuzhi">
                  <span class="spantit">订房必读</span>
                  <p>
                    根据首都严格进京管理联防联控协调机制发布，进（返）京须持48小时内核酸检测阴性证明和“北京健康宝”绿码的基础上，进返京人员在抵京后72小时内需进行一次核酸检测，以上信息供您参考，入住前建议跟酒店再次确认最新政策要求，以免影响办理入住。
                  </p>
                </div>
              </div>
              <div class="blocks">
                <div class="blocklist yuding">
                  <span class="spantit">预定信息</span>
                  <div class="reserve">
                    <!--日期  -->
                    <div class="riqi">

                    </div>
                    <!-- 房间数下拉 -->
                    <div class="house">
                      <p>房间数量</p>
                      <div class="house_text" @click="getroom()">
                        <div class="getroom">{{roomIndex}}</div>
                        <div class="roomnums" v-show="roomshow" :class="roomshow?'active':''">
                          <ul>
                            <li v-for="(list, index) in roomlist"
                              :key="index"
                              @click.stop="getnums(list)"
                              :class="roomIndex == list ? 'cur' : ''">{{list}}</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="blocks">
                <div class="blocklist zhuke">
                  <span class="spantit">住客信息</span>
                  <div class="rooms">
                    <div class="roomslist">
                      <p>房间1(姓名)</p>
                      <input type="text" placeholder="每间房填一人姓名即可" >
                    </div>
                    <!-- <div class="roomslist">
                      <p>房间2(姓名)</p>
                      <input type="text" placeholder="每间房填一人姓名即可">
                    </div> -->
                  </div>
                  <div class="dianhua">
                    <p>电话号码</p>
                    <!-- 地区 -->
                    <div class="dianhua_cont">
                      <div class="phone_group">
                        <div class="region" @click.stop="phoneis()"> 
                          <span>{{bianhao}}</span>
                          <img class="phone_group_jt" src="../../assets/img/jt.png" :class="phoneshow?'active':''" alt=""> 
                        </div>                   
                        <ul class="dropul"  :class="phoneshow?'active':''"> 
                          <li class="dropul_li" v-for="(region,index) in regions" :key="index" @click="setregion(region.zone)" :class="bianhao==region.zone?'active':''">
                            {{region.state}}
                            <span class="dropul_span">{{region.zone}}</span>
                          </li>
                          <!-- regions -->
                        </ul>
                      </div>  
                      <input type="text" placeholder="电话号码" class="phones">
                    </div>
                  </div>
                  <div class="youxiang">
                    <p>邮箱地址</p>
                    <input type="text" placeholder="输入后请核查一下，避免输入错误" class="phones">
                  </div>
                </div>
              </div>
              <div class="blocks" >
                <div class="blocklist daodian">
                  <span class="spantit">到店时间</span>
                  <div class="daodian_text">
                    <p>客房14:00可办理入住</p>
                    <p>24小时前台-随时提供帮助！</p>
                    <p>预计到店时间（可选）</p>
                  </div>
                  <div class="time"
                    @click.stop="gettime()"
                    :class="timeshow ? 'active' : ''">
                    <div class="gettimePart">
                      <!-- <span class="getHour">00</span>
                      <span>:</span>
                      <span class="getMinute">00</span>
                      <span>请选择</span> -->
                      {{
                        timehour != "" && timeminute != ""
                          ? timehour + ":" + timeminute
                          : "请选择"
                      }}
                    </div>
                    <div class="timePart" v-if="timeshow">
                      <ul>
                        <li id="selHour">
                          <!-- <p>时</p> -->
                          <ol>
                            <!-- <li class="" @click="gethour(index,hour)">{{hour}}</li> -->
                            <li
                              v-for="(hour, index) in hours"
                              :key="index"
                              @click.stop="gethour(index, hour)"
                              :class="hoursIndex == index ? 'cur' : ''"
                            >
                              {{ hour }}
                            </li>
                            <!-- <li class="cur" >00</li> -->
                          </ol>
                        </li>
                        <li id="selMinute">
                          <!-- <p>分</p> -->
                          <ol>
                            <!-- <li class="cur">00</li> -->
                            <li
                              v-for="(minute, index) in minutes"
                              :key="index"
                              @click.stop="getminute(index, minute)"
                              :class="minutesIndex == index ? 'cur' : ''"
                            >
                              {{ minute }}
                            </li>
                          </ol>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="blocks">
                <div class="blocklist fapiao">
                  <span class="spantit">发票信息</span>
                  <p>如需要发票，请在入住当天从酒店前台索取</p>
                  <!-- <div class=""></div> -->
                  <span class="spantit">支付方式</span>
                  <div class="zhifu">
                    <div class="zhifulist">
                      <div class="zhifuicon" @click="payment(1)">
                        <img v-if="zhifu==1" src="../../assets/img/xz.png" alt="" />
                        <img v-if="zhifu==2" src="../../assets/img/wxz.png" alt="" />
                      </div>
                      <p>微信支付</p>
                    </div>
                    <div class="zhifulist">
                      <div class="zhifuicon" @click="payment(2)">
                        <!-- <img :class="zhifu==1?'img2':'img1'" src="../../assets/img/xz.png" alt="" />
                        <img :class="zhifu==1?'img1':'img2'" src="../../assets/img/wxz.png" alt="" /> -->
                        <img v-if="zhifu==2" src="../../assets/img/xz.png" alt="" />
                        <img v-if="zhifu==1" src="../../assets/img/wxz.png" alt="" />
                      </div>
                      <p>酒店前台支付</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="blocks">
                <div class="blocklist dinggou">
                  <div class="tiaokuan">
                    <img src="../../assets/img/xz.png" alt="" />
                    <p>同意</p><span>使用条款</span>
                  </div>
                  <div class="price">
                    <div class="price_text">
                      <p>价格：</p>
                      <span>￥4160元</span>
                    </div>
                    <div class="price_pay">去订购</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="order_right">
              <span class="spantie">订单详情</span>
              <div class="tupian">
                <img src="../../assets/img/room1.jpg" alt="" />
              </div>
              <div class="jieshao">
                <div class="blo1">
                  <span class="spnas">房型：</span>
                  <p>1.8米水景大床房</p>
                </div>
                <div class="blo2">
                  <div class="blo2_left">
                    <span class="spnas">入住时间：</span>
                    <p>2022年4月20日</p>
                    <p>星期三 14:00起</p>
                  </div>
                  <div class="blo2_right">
                    <span class="spnas">退房时间：</span>
                    <p>2022年4月22日</p>
                    <p>星期四 12:00前</p>
                  </div>
                </div>
                <div class="blo3">
                  <span class="spnas">入住总天数：</span>
                  <p>2晚</p>
                </div>
                <div class="blo4">
                  <span class="spnas">价格汇总</span>
                  <div class="jiage">
                    <p>房费：一晚一间</p>
                    <p>￥4160元</p>
                  </div>
                </div>
              </div>
              <div class="yingfu">
                <p>应付总额：</p>
                <p>￥4160元</p>
              </div>
              <div class="quxiao">
                <p>取消规则</p>
                <p>
                  您可以在2022年04月19日 1:
                  00前免费取消或变更订单；在2022年04月19日 1:
                  00之后变更或取消，将收取全额房费作为违约费用。若您已办理入住，则订单不可变更或取消。
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 公共底部 -->
    <Footer />
  </div>
</template>

<script>
import Header from "../owned/header.vue";
import Footer from "../owned/footer.vue";
// import Swiper from "swiper";
export default {
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      hours: [
        "00",
        "01",
        "02",
        "03",
        "04",
        "05",
        "06",
        "07",
        "08",
        "09",
        "10",
        "11",
        "12",
        "13",
        "14",
        "15",
        "17",
        "18",
        "19",
        "20",
        "21",
        "22",
        "23",
      ],
      hoursIndex: 0,
      minutes: [
        "00",
        "01",
        "02",
        "03",
        "04",
        "05",
        "06",
        "07",
        "08",
        "09",
        "10",
        "11",
        "12",
        "13",
        "14",
        "15",
        "17",
        "18",
        "19",
        "20",
        "21",
        "22",
        "23",
        "24",
        "25",
        "26",
        "27",
        "28",
        "29",
        "30",
        "31",
        "32",
        "33",
        "34",
        "35",
        "36",
        "37",
        "38",
        "39",
        "40",
        "41",
        "42",
        "43",
        "45",
        "46",
        "47",
        "38",
        "49",
        "50",
        "51",
        "52",
        "53",
        "54",
        "55",
        "56",
        "57",
        "58",
        "59",
      ],
      minutesIndex: 0,
      timeshow: false,
      time: "", //传到后台的时间
      timehour: "", //选择展示的小时
      timeminute: "", //选择展示的分钟
      phoneshow:false,
      zhifu:1,// 支付方式选择
      regions:[],//地区编号数组
      bianhao:'+86',//传到后台的区号
      roomlist:['1','2','3','4'],//房间数量列表
      roomIndex:1,//传到后台的房间数量默认1
      roomshow:false
    };
  },
  created() {
    // 储存第几个头部状态
    localStorage.setItem("istrue", 2);
    // console.log(this.Baseurl)
    this.getregion()
  },
  methods: {
    //获取地区编号
    getregion(){
      // http://ssjydfd.sc798.com/zone_list
      var that =this
      that.$axios
        .get(`${this.Baseurl}/zone_list`) 
				.then(function(res) {
					// console.log(res)	
          that.regions=res.data.data
          // console.log(that.regions)
			}).catch(err => console.log(err));
      // this.$axios(
      //   {
      //     url: this.Baseurl+'/zone_list',
      //     method: 'GET',
      //     // dataType: 'jsonp',
      //     // data: {}
      //   }
      // ).then(response => {
      //   console.log(response)
      // }).catch(err => console.log(err));
    },
    //设置地区编号
    setregion(region){
      console.log(region)
      this.bianhao=region
      this.phoneshow = false
    },
    //打开关闭地区下拉
    phoneis(){
      this.phoneshow =!this.phoneshow
    },
    //打开选择时间下拉
    gettime() {
      // this.timeshow=true
      this.timeshow = !this.timeshow;
    },
    // 选择小时
    gethour(index, hour) {
      this.hoursIndex = index;
      // console.log(index,hour)
      this.timehour = hour;
      if (this.timehour != "" && this.timeminute != "") {
        this.timeshow = false;
      }
    },
    //选择分钟
    getminute(index, minute) {
      this.minutesIndex = index;
      // console.log(index,minute)
      this.timeminute = minute;
      if (this.timehour != "" && this.timeminute != "") {
        this.timeshow = false;
      }
    },
    //关闭选择时间下拉
    timeclose() {
      this.timeshow = false;
    },
    payment(num){
      this.zhifu = num
    },
    //房间数量的选择
    getroom(){
      this.roomshow=!this.roomshow
    },
    getnums(list){
      this.roomIndex=list
      this.roomshow=false
    }
    
  },
  mounted() {},
};
</script>
<style scoped>
.order {
  background-color: #efefed;
}
.orderdetail {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding-bottom: 15px;
}
.orderdetail .order_left {
  width: 978px;
}

.orderdetail .order_left .blocks {
  background-color: #fff;
  margin-bottom: 15px;
  padding: 30px 0;
}
.blocklist {
  width: 900px;
  margin: auto;
}
.blocklist .spantit {
  font-size: 24px;
  color: #000000;
  font-weight: 400;
}
.xuzhi p {
  font-size: 18px;
  color: #000000;
  line-height: 30px;
  margin-top: 15px;
  text-align: justify;
}
/* 到店时间 */
.daodian_text {
  margin-top: 15px;
}
.daodian_text p {
  font-size: 18px;
  color: #000000;
  line-height: 30px;
}
/* 发票信息 支付方式 */
.fapiao>p{
  /* line-height: 30px; */
  margin-top: 10px;
  margin-bottom: 20px;
  font-size: 18px;
  color: #000000;
}
.fapiao .zhifu {
  margin-top: 10px;
  display: flex;
  align-items: center;
}
.fapiao .zhifu .zhifulist {
  display: flex;
  align-items: center;
  margin-right: 20px;
}

.fapiao .zhifu .zhifulist .zhifuicon {
  width: 17px;
  height: 17px;
  /* overflow: hidden; */
  cursor: pointer;
}
.fapiao .zhifu .zhifulist .zhifuicon img {
  width: 100%;
  display: block; 
}
.fapiao .zhifu .zhifulist .zhifuicon img:hover{
  opacity: 0.8;
}
.fapiao .zhifu .zhifulist p {
  font-size: 18px;
  color: #000000;
  margin-left: 12px;
}
/* 使用条款 去订购 */
/* .dinggou{

} */
.tiaokuan{
  display: flex;
  align-items: center;
}
.tiaokuan img{
 width: 17px;
  height: 17px;
  cursor: pointer;
}
.tiaokuan img:hover{
  opacity: 0.8;
}
.tiaokuan p{
  font-size: 18px;
  color: #000000;
  margin-left: 12px;
   height: 25px;
}
.tiaokuan span{
  font-size: 18px;
  color: #206079;
  display: inline-block;
  box-sizing: border-box;
  height: 25px;
  border-bottom: 1px solid #206079;
  cursor: pointer;
}
.price{
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
}
.price .price_text{
  display: flex;
  align-items: center;
}
.price .price_text p{
  font-size: 18px;
  color: #000000;
  margin-left: 12px;
}
.price .price_text span{
  font-size: 30px;
  color: #206079;
  font-weight: 400;

}
.price_pay{
  width: 190px;
  height: 60px;
  background-color: #d5b08b;
  font-size: 20px;
  color: #fff;
  text-align: center;
  line-height: 60px;
  cursor: pointer;
}


.orderdetail .order_right {
  width: 400px;
  background-color: #fff;
  padding: 30px 0;
}
.orderdetail .order_right > .spantie {
  font-size: 24px;
  color: #000000;
  font-weight: 400;
  padding: 0 20px;
}
.orderdetail .order_right > .tupian {
  width: 100%;
  margin-top: 30px;
}
.orderdetail .order_right > .tupian img {
  width: 100%;
  display: block;
}
.jieshao {
  padding: 0 20px;
}
.jieshao .spnas {
  font-size: 18px;
  color: #000000;
  font-weight: 400;
  margin-bottom: 10px;
  display: block;
}
.jieshao p {
  font-size: 18px;
  color: #000000;
}
/* blo2_left */
.blo1 {
  margin-top: 20px;
}

.blo2 {
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
}

.blo2 .blo2_left {
  width: 125px;
  position: relative;
  /* background: pink; */
}

.blo2 .blo2_left::after {
  position: absolute;
  content: "";
  width: 1px;
  height: 45px;
  bottom: 7px;
  right: -55px;
  background-color: #f2f2f2;
}
.blo2 .blo2_right {
  width: 125px;
  /* background: pink; */
}
.blo3 {
  margin-top: 20px;
  border-bottom: 1px solid #e5e5e5;
  padding-bottom: 20px;
}
.blo4 {
  margin-top: 20px;
}
.blo4 .jiage {
  display: flex;
  justify-content: space-between;
}
.yingfu {
  padding: 0 20px;
  background-color: #d5b08b;
  display: flex;
  justify-content: space-between;
  height: 70px;
  align-items: center;
  margin-top: 20px;
}
.yingfu p {
  font-size: 20px;
  color: #fff;
}
.quxiao {
  padding: 0 20px;
  margin-top: 20px;
}

.quxiao p {
  font-size: 16px;
  color: #5f5f5f;
  line-height: 30px;
  text-align: justify;
}

/* 时间选择器 */
.time {
  width: 220px;
  height: 30px;
  border-bottom: 1px solid rgb(118, 118, 118);
  margin-right: 40px;
  position: relative;
  display: flex;
  align-items: center;
  cursor: pointer;
}
.time.active::after {
  transform: rotate(90deg);
}
.time::after {
  position: absolute;
  content: "";
  width: 9px;
  height: 17px;
  bottom: 3px;
  right: 10px;
  transform: rotate(-90deg);
  background-image: url("../../assets/img/jt.png");
  background-repeat: no-repeat;
  background-size: 100%;
}
ol,
ul,
li {
  list-style: none;
}
.gettimePart {
  width: 100%;
  height: 100%;
  line-height: 30px;
  /* padding-left: 10px; */
  font-size: 18px;
  color: #5f5f5f;
  cursor: pointer;
}
.timePart {
  text-align: center;
  color: #333;
  line-height: 22px;
  /* background: #c0b7b7; */
  position: absolute;
  top: 40px;
  left: 10px;
  box-shadow: 2px 2px 15px #ccc;
}

.timePart p,
.timePart ul {
  background: #fff;
}

.timePart > ul > li {
  float: left;
  width: 60px;
  background: #fff;
  color: #333;
  border-right: none;
}

.timePart ul {
  overflow: hidden;
  padding-top: 5px;
}

.timePart > ul > li p {
  line-height: 30px;
  border-bottom: 1px solid #ccc;
}

.timePart ol {
  width: 60px;
  height: 250px;
  overflow-y: hidden;
  *overflow-y: auto;
  overflow-x: hidden;
}
.timePart ol::-webkit-scrollbar {
  display: none;
}

.timePart ol:hover {
  overflow-y: auto;
}

.timePart ol li {
  line-height: 30px;
  text-align: center;
  width: 50px;
  height: 35px;
  line-height: 35px;
  margin: auto;
  color: #000;
}
.timePart ol li:hover {
  /* background: #7eb9ff;  */
  background: #ead7c3;
}
.timePart ol li.cur {
  background: #d5b08b;
  color: #fff;
}

::-webkit-input-placeholder { /* WebKit browsers */
  color:#5f5f5f;
}

:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
  color:#5f5f5f;
}

::-moz-placeholder { /* Mozilla Firefox 19+ */
  color:#5f5f5f;
}

:-ms-input-placeholder { /* Internet Explorer 10+ */
  color:#5f5f5f;
}

/* 住客 */
.roomslist{
  margin-top: 20px;
}
.roomslist>p{
  font-size: 18px;
  color: #000000;
  font-weight: 400;
}
.roomslist>input{
  width: 325px;
  border: none;
  border-bottom: 1px solid #868686;
  font-size: 18px;
  color: #5f5f5f;
  /* padding: 0 10px; */
  box-sizing: border-box;
  height: 30px;
  outline: none;
  margin-top: 10px;
}

/* 邮箱 */
.youxiang{
  margin-top: 20px;
}
.youxiang>p{
  font-size: 18px;
  color: #000000;
  font-weight: 400;
}
.youxiang>input{
    width: 325px;
  border: none;
  border-bottom: 1px solid #868686;
  font-size: 18px;
  color: #5f5f5f;
  /* padding: 0 10px; */
  box-sizing: border-box;
  height: 30px;
  outline: none;
  margin-top: 10px;
}


/* 电话前缀+86 */
.dianhua{
  margin-top: 20px;
}
.dianhua >p{
  font-size: 18px;
  color: #000000;
  font-weight: 400;
  
}
.dianhua_cont{
  display: flex;
  margin-top: 10px;
}
.dianhua_cont .phones{
  width: 200px;
  border: none;
  border-bottom: 1px solid #868686;
  font-size: 18px;
  color: #5f5f5f;
  padding: 0 10px;
  box-sizing: border-box;
  height: 30px;
  margin-left: 15px;
  outline: none;
}
.phone_group{
  width: 110px;
  position: relative;
  height: 30px;
  border-bottom: 1px solid #868686;
  box-sizing: border-box;
}
.phone_group .region{
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px;
  cursor: pointer;
}
.phone_group .region span{
  font-size: 18px;
  color: #000000;
  font-weight: 400;
}
.phone_group_jt{
  width: 9px;
  height: 17px;
  display: block;
  transform: rotate(-90deg);
  /* transition: all 0.5s; */
}
.phone_group_jt.active{
  transform: rotate(90deg);
}
.phone_group .dropul {
  /* height: 360px; */
  height: 0;
  overflow: hidden;
  width: 250px;
  /* width: 320px; */
  /* text-transform: lowercase; */
  position: absolute;
  z-index: 9;
  top: 32px;
  left: 0;
  overflow-y: scroll;
  background-color: white;
  border: 1px solid #fff; 
  transition: all 0.5s;
}
.phone_group .dropul.active{
  height: 360px;
  
    /* border: 1px solid lightgray;  */
    box-shadow: 0 8px 20px 0 rgb(0 41 99 / 20%);
}

.phone_group .dropul .dropul_li {
    color: #6b6a6a;
    font-size: 16px;
    line-height: 30px;
    font-weight: 300;
    cursor: pointer;
    padding-left: 10px;
    
}
.phone_group .dropul .dropul_li:hover{
  background: #d5b08b;
  color: #fff;
}
.phone_group .dropul .dropul_li.active{
  background: #d5b08b;
  color: #fff; 
}
.phone_group .dropul .dropul_span {
    float: right;
    font-size: 16px;
    font-weight: 300;
    padding-right: 10px;
}


/* 预定信息 房间数量 */
.yuding .house>p{
  font-size: 18px;
  color: #000000;
  font-weight: 400;
}
.yuding .house .house_text{
  width: 200px;
  height: 30px;
  border-bottom: 1px solid rgb(118, 118, 118);
  margin-right: 40px;
  position: relative;
  display: flex;
  align-items: center;
  cursor: pointer;
}



.yuding .house .house_text::after {
    position: absolute;
    content: "";
    width: 9px;
    height: 17px;
    bottom: 3px;
    right: 10px;
    transform: rotate(-90deg);
    background-image: url("../../assets/img/jt.png");
    background-repeat: no-repeat;
    background-size: 100%;
}
.yuding .house .house_text.active::after {
    transform: rotate(90deg);
}
.yuding .house .house_text .getroom{
  width: 100%;
    height: 100%;
    line-height: 30px;
    /* padding-left: 10px; */
    font-size: 18px;
    color: #5f5f5f;
    cursor: pointer;
}
.roomnums{
  width: 200px;
  text-align: center;
  color: #333;
  line-height: 22px;
  position: absolute;
  top: 40px;
  left: 0;
  background: #fff;
  box-shadow: 2px 2px 15px #ccc;
}
.roomnums ul{

}
.roomnums ul li{
  line-height: 30px;
  text-align: center;
  width: 100%;
  height: 35px;
  line-height: 35px;
  margin: auto;
  color: #000;
  font-size: 18px;
}
.roomnums ul li.cur{
  background: #d5b08b;
  color: #fff;
}
.roomnums ul li:hover{
  background: #ead7c3;
}

/* <div class="house_text">
                        <div class="getroom">1</div>
                        <div class="roomnums">
                          <ul>
                            <li v-for="(list, index) in roomlist"
                              :key="index"
                              @click.stop="getnums(index, list)"
                              :class="roomIndex == list ? 'cur' : ''">1</li>
                            <li>2</li>
                            <li>3</li>
                            <li>4</li>
                          </ul>
                        </div>
                      </div> */
</style>
